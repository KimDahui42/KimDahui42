# Ch3_Scheduling

사람: Jeon Jeon
완료 여부: No
주차: 1주차, 2주차, 3주차, 4주차

# Manual Schedule

## Manual Schedule

Kubernetes에서 Scheduler가 따로 설정되어있지 않는 경우, 기본적으로 kube-scheduler라는 컴포넌트가 pod를 어떤 노드에 배치할지 결정한다.

만약 클러스터에  Shceduler 아예 없거나 비활성화 되어있는 경우, pod는 Pending 상태로 멈춰있게된다.

kubernetes Scheduler의 동작 방식

1. pod가 생성된다. (처음 생성된 pod는 spec.nodeName이 비어있음)
2. kube-scheduler는 nodeName이 없는  pod를 감지
3. Scheduling 알고리즘을 통해 적절한 노드를 선택 (공식 문서에는 ‘kube-scheduler는 새로 생성되었거나 아직 예약되지 않은(스케줄링되지 않은) 파드를 실행할 최적의 노드를 선택한다. 파드의 컨테이너와 파드 자체는 서로 다른 요구사항을 가질 수 있으므로, 스케줄러는 파드의 특정 스케줄링 요구사항을 충족하지 않는 모든 노드를 필터링한다.’ 라고 작성되어 있다.)
4. spec.nodeName에 선택된 노드의 이름을 설정
5. 내부적으로 Binding 객체를 생성하여 할당한다.

그런데 이미 존재하는 Pod를 Node에 할당하고 싶다면 kubernetes가 nodeName을 못 고치게 해서 안됨

때문에 정 하고 싶다면 Binding Object를 생성하고 Binding API로 요청을 보내야 함  (Scheduler 기능을 모방)

ex

curl —header “Content-Type:application/json” —request Post —data ‘{”apiVersion”:”v1”, “kind”:”Binding” ….여기에 타겟 노드값을 넣음}’ http://$SERVER/api/v1/namespace/default/pods/$PODNAME/binding/

—> 그래서 binding yaml을 JSON으로 변형하고 쏴야함

## Practice Test - Manual Scheduling

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image.png)

우선 ls로 진짜 yaml이 있는지 보자

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%201.png)

오케이 확인

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%202.png)

시원하게 kubectl create를 질렀지만 터졌다 먼가 더 필요하단다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%203.png)

gpt한테 물어보니까 -f가 없댄다 여기서 -f는 우리가 비밀스럽게쓰는 force가 아니라 -file이었다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%204.png)

gpt선생님 말씀대로 정상적으로 만들어지는 것을 알 수 있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%205.png)

정답이란다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%206.png)

만들어진 Pod의 상태를 물어본다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%207.png)

get으로 보면 Pending이 된 것을 볼 수 있다. 뭄샤드 센세가 말한 스케줄링이 없는 경우인가보다.

아니나 다를까 Pending을 누르면 무자비하게 3번으로 이동한다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%208.png)

3번에서는 기다렸다는 듯이 이유를 물어본다. 아는 이유가 No Scheduler밖에 없으니 두 번째를 눌렀다.

정답이다.

뭄샤드는 kubectl describe pod nginx를 사용해 상태를 확인했다.

뭄샤드가 한거 꼭 실습 돌려서 스샷함 찍어봐라원빈아

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%209.png)

수동 스케줄링을 하란다.

kubectl edit pod nginx로 수정하려고 접속했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2010.png)

어느 줄에 넣어야 할지 도통 모르겠다. 폭탄 해체를 yaml로 할 줄 몰랐다 깔끔하게 포기했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2011.png)

bind를 쓰는 방법도 있다고 했지만 어려워서 지우고 다시 실행하려한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2012.png)

vi 편집기로 nginx.yaml에 들어간 화면이다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2013.png)

spec 밑에 nodeName을 만들고 스케줄링하는 노드를 썼다

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2014.png)

1번방법으로 생성하고 확인했다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2015.png)

이번엔 controlplane에 하란다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2016.png)

똑같이 pod을 지우고 yaml의 nodeName을 수정했다.(지우지 않고 yaml 수정 → kubectl replace —force -f nginx.yaml로 지우기와 실행을 한번에 하는 방법도 있다.)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2017.png)

pod이 실행 될 때까지 생각보다 시간이 걸린다. X를 보고 좌절 하지 말고 조금 기다렸다 돌리면

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2018.png)

예스~

# Labels and Selector

## Labels

그룹화 하거나 필터링을 할 때 제일 좋은 방법은 레이블을 이용하는 것

Label은 각각 Item에 부착된 Property이고 이것을 추가 가능

Selector는 이것으로 필터링 하는 것을 도와줌

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2019.png)

이런 거 같은 거임

쿠버네티스엔 매우많은 종류의 Object가 있기 때문에 Object의 개수가 많아진다면 관리가 힘들기에 필터링을 해서 봐야한다.

Label을 작성하는 법은 yaml파일 metadata 하위에 labels 를 작성하고 그 밑에 key: value로 Label을 추가하면 됨

이렇게 지정한 Label을 Selector로 사용하려면

kubectl get pods —selector app=App1이런 식으로 쓰면됨

ReplicaSet에서 Selector를 사용하면 같은 방식으로 사용하면 됨 그런데 spec: → template: → labels: 밑에 작성된 Label은 복제된 Pod의 Label이므로 헷갈리지 말 것

여기서 이  ReplicaSet과 복제된 Pod을 연결하기 위해 spec: → matchLabels에 Label에 작성해야함

matchLabels랑 metadata의 labels랑 같아야 ReplicaSet이 성공적으로 만들어짐

## Annotation

metadata: 밑에 annotations라는 게 있는데 이건 빌드버전, 툴 정보, 이메일 같은 걸 적는데 쓴다 말 그대로 주석으로 쓰는 가봄

## Practice Test - Labels and Selectors

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2020.png)

tier, env, bu라는 라벨을 가진 Pod이 있는데 이중에서 env 라벨에서 dev라는 값을 가진 Pod가 몇개인지 물어본다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2021.png)

kubectl get pods —selector env=dev를 실행해 —selector 옵션을 사용해 실행했다.

총 7개의 pod이 나왔다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2022.png)

—no-headers(헤더를 없애는 옵션) | wc(wordcount)-l을 이용하면 갯수만 깔끔하게 나온다

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2023.png)

bu유닛에서 finance값의 pod이 몇 개냐고 물어본다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2024.png)

1번과 같은 방법으로 pod을 확인했다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2025.png)

enviroment에서 prod값을 가진 object가 몇 개인지 물어본다.(여기서 enviroment는 env 키를 말한다. 1번에서 쓰고 여기서 안 말해줘서 뭄샤드 형님의 불친절함에 감탄했다.)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2026.png)

kubectl get all —selector env=prod 를 실행해 object를 확인했다. 4개의 pod 하나의 service 두 개의 replicaset을 확인했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2027.png)

—no-headers를 사용하면 7개라고 나온다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2028.png)

env=prod고 bu=finance , tier=frontend인 pod을 찾으라고 한다

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2029.png)

app-1-zzxdf가 나온다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2030.png)

replicaset을 정의한 yaml이 있다고 한다. 에러가 뜰 건데 이걸 고치고 만들어라 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2031.png)

돌리니까 이런 경고가 뜨면서 안된다 한다. label이 안 맞는 거 같다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2032.png)

보면 spec→selector→matchLabels에 tier=front-end밖에없고 생성하는 pod은 tier:nginx의 라벨을 가진다. 이거 때문에 연결이 안된 것 같다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2033.png)

matchLabels에 tier값을 nginx로 수정했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2034.png)

create를 통해 replicaset을 만들었다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2035.png)

성공이다.

# Taints And Tolerations

노드에 어떤 pod를 배치할지 제한하는 것

Taint - node의 설정

Toleration - Pod의 설정

Taint를 설정하게 되면 이 값에 맞지 않는 Pod은 배치될 수 없음

이를 위해서 Pod배치를 원하는 pod에 Toleration을 설정해야함

ex) Taint=blue로 설정된 node에는 Toleration=blue인 Pod만 배치 가능

Taint를 설정하기 위해선 kubectl taint nodes 노드이름 key =value :Effect(여기에는 Toleration이 맞지않으면 어떤 일이 생길지 결정)

Effect로 가능 한 3가지 설정 .

- NoSchedule
    - 그 Tainit Node에 Pod의 Scheduling을 허용하지 않음
    - 기존 실행 중인 Pod는 어쩔 수 없고, 앞으로 실행될 Pod에 대해서만 Scheduling 제한
- NoExecute
    - 그 Tainit Node에 Pod의 실행을 허용하지 않음
    - 앞으로 생성 될 Pod에 대한 Scheduling을 제한함은 물론, 기존에 해당 Node에 배치된 Pod 모두 방출
- PreferNoSchedule
    - 그 Taint Node에 Pod Scheduling을 선호하지 않음
    - Soft룰이라 할 수 있다.
    - 기존 실행 중인 Pod는 허용하고, 앞으로 생성될 Pod도 Scheduling되는 것을 선호하진 않지만, 해당 Node 밖에 Scheduling될 곳이 없다면 허용해줌

pod에서 이걸 수용할 Toleration을 만들려면

spec→toleration: 항목을 만들고

‘ - key : 키값

     operator: 기호

    value : 밸류값

    effect : 이펙트값’

을 넣으면 된다.

kubectl taint nodes node1 app=blue  :NoSchedule을 에 대응하는 toleration을 만들려면

```jsx
apiVersion:
kind: Pod
metadata: 
 name: myapp-pod
spec:
 containers:
  - name: nginx-container
    image: nginx
 tolerations:
  - key: "app"
    operator: "Equal"
    value: "blue"
    effect: "NoSchedule"
```

이렇게 적성 하면 된다.

주의)Taint와 Toleration은 꼭 특정Node에 특정Pod을 배치하는 특성이 아닌 수용의 설정이므로 원하는 Node에 배치가 안 될 수 있다.

Master node는 kubernetes가 처음 실행되면 자동으로 Taint을 설정해 어떤pod도 실행되지 못하게 한다

kubectl describe node kubemaster | grep Taint를 실행하면 확인이 가능하다.

## Practice Test - Taints and Tolerations

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2036.png)

controlpane를 포함한 node의 개수를 써라

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2037.png)

두 개가 있는 것을 볼 수 있다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2038.png)

node01에 taint가 있는지 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2039.png)

describe를 실행해 Taint를 보니 아무것도 없다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2040.png)

node01에 spray=mortein:NoSchedule의 Taint를 만들어라한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2041.png)

kubectl taint nodes node01 spray=mortein:NoSchedule를 실행시켰다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2042.png)

오케이

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2043.png)

image는 nginx고 이름은 mosquito인 pod을 만들어라한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2044.png)

ls로 찾으니 sample.yaml을 주었다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2045.png)

아무것도 없다.

[https://kubernetes.io/docs/concepts/workloads/pods/](https://kubernetes.io/docs/concepts/workloads/pods/) 공식 사이트에서 래퍼런스를 찾았다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2046.png)

모르는 값은 지우고 간단하게 만들었다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2047.png)

pod을 만들었다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2048.png)

정답이다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2049.png)

pod의 상태를 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2050.png)

Pending 상태인 것을 알 수 있다.

### 6.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2051.png)

왜 pending상태인지 물어본다.

몰라서 kubectl describe pods mosquito를 통해 찾았다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2052.png)

Event에서 taint가 없어서 노드에 못 올렸다 한다.

### 7.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2053.png)

mortain에 배치할 수 있는 bee라는 pod을 만들라한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2054.png)

아직 만들어 놓은 yaml 이 살아있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2055.png)

이렇게 작성한다. “는 빼도 된다.

create하다 속성에 Effect처럼 대문자를 붙여서 그랬다. 절대 대문자는 쓰지 말자

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2056.png)

다시 수정했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2057.png)

bee 생성

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2058.png)

정답이다.

### 8.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2059.png)

taint때문에 bee는  node01에 올라올 수 있었단다.

kubectl describe nodes node01에서 찾으니

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2060.png)

맞다는 것을 알았다.

### 9.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2061.png)

controlplane에 있는 taints를 확인하란다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2062.png)

암것도 없다

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2063.png)

틀렸다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2064.png)

대소문자를 주의하자

### 10.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2065.png)

controlplane의 taint를 지우라고 한다.

지우는 법은 안 배운 것 같지만 공식 문서를 보니

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2066.png)

마지막에 -를 붙이면 없어진다 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2067.png)

위에서 describe로 확인한 taint를 붙이고 -를 붙였다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2068.png)

성공

### 11.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2069.png)

mosquito의 상태를 물어본다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2070.png)

실행되고 있다.

### 12.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2071.png)

어떤 노드에서 실행되냐 묻는다.

kubectl get pods mosquito -o(—output) wide로 node의 정보까지 확인했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2072.png)

controlplane에서 도는 것을 알 수 있다.

# NodeSelectors

노드마다, 포드마다 필요한 자원이 다르다 때문에 이를 위해 노드에 한계를 설정해야한다.

그 방법 중 하나가 NodeSelector다

NodeSelector사용법

pod yaml에서 Sepc→nodeSelector→node의 Label키 :node의 Label값을 작성해 설정할 수 있다.

예시를 보면

```jsx
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
    env: test
spec:
  containers:
  - name: nginx
    image: nginx
    imagePullPolicy: IfNotPresent
    ##이 부분이 NodeSelector를 적은 부분##
  nodeSelector:
    disktype: ssd
```

node에서 Label을 설정하기 위해서는

kubectl label nodes <node-name> <label-key> = <label-value>로 설정할 수 있다.

하지만 NodeSelector는 OR이나 NOT 같은 복잡한 요구 사항을 수행할 수  단점이 있다. 때문에 사용하는 것이 Node Affinity이다.

# Node Affinity

Node Affinity의 목적은 포드가 특정 노드에 호스팅 될 수 있도록 하는 것

Node Affinity는 특정 Node에 Pod 배치를 제한하는 기능을 가지고 있다.

예시를 보면

```jsx
apiVersion: v1
kind: Pod
metadata:
  name: with-node-affinity
spec:
  affinity:
    nodeAffinity:
    ##스케줄링동안 필요하고 실행중에는 무시된다고 써져있다. 뭄샤드는 걍 읽는대로 이해하면 된다는데
      내 모국어는 한국어다##
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        ##여기서 보면 전에 배운 Toleration마냥 operator랑 key, value가 있는 것을 볼 수있다.
	        그 뜻은 더 복잡한 조건도 가능하다는 이야기가 된다##
        - matchExpressions:
          - key: size
          ## NotIn이나 Exists같은 연산도 있다.##
            operator: In
            values:
          ##여기에 다른 값이 필요하면 -Medium이런 방식으로 넣을 수 있다.## 
            - Large
      preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 1
        preference:
          matchExpressions:
          - key: another-node-label-key
            operator: In
            values:
            - another-node-label-value
  containers:
  - name: with-node-affinity
    image: registry.k8s.io/pause:2.0
```

이런  yaml을 실행하면 Scheduling시에 Affinity를 고려해 배포된다.

Node Affinity는

- `requiredDuringSchedulingIgnoredDuringExecution`
- `preferredDuringSchedulingIgnoredDuringExecution`

이처럼 Scheduling과 Execution시에 어떻게 할지 설정할 수 있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2073.png)

 예로 이 표의 Type 1를 보면 `requiredDuringSchedulingIgnoredDuringExecution` 상태이고 이때는 조건에 맞는 Node가 없으면 Scheduling이 되지 않는다.

Type 2는 `referredDuringSchedulingIgnoredDuringExecution` 상태이고 조건에 맞는 Node가 없어도 Scheduling이 가능하다

 Type 3는 `requiredDuringSchedulingRequiredDuringExecution` 상태로 조건에 맞는 Node가 없으면 Scheduling이 되지 않고 실행이 Node안에서 실행이 되면 Pod이 종료하거나 퇴출 된다.

## Practice Test - Node Affinity

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2074.png)

node01의 Label 수를 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2075.png)

describe로 찾아봤다

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2076.png)

다섯 개가 있는 것을 볼 수 있다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2077.png)

[beta.kubernetes.io/arch](http://beta.kubernetes.io/arch에) 키에 대한 값을 묻는다. 1번에서 확인했듯이 amd64이다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2078.png)

키가 color이고 값이 blue인 label을 작성하라 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2079.png)

kubectl label node  node01 color=blue를 실행해 label을 추가했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2080.png)

정답이다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2081.png)

nginx 이미지에 blue라는 이름이고 replica가 3으로 설정된 deployment를 만들라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2082.png)

create deployment를 이용해 생성했다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2083.png)

blue deployment의 Pod가 배치 될 수 있는 노드를 찾으라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2084.png)

node01과  controlplane에  Taint가 없으므로 아무 데나 가능하다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2085.png)

deployment에 node Affinity를 적용해서 pod이 node01에만 배포되게 하라한다..

이번엔 yaml도 없으니 edit을 사용하겠다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2086.png)

kubectl edit deployment blue을 실행하면 blue의 yaml로 이동한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2087.png)

이상한 것이 잔뜩 있지만 Node Affinity는 Pod의 Spec아래 추가만 하면 된다.

```jsx
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: color
            operator: In
            values:
            - blue
```

blue에만 이니까 공식문서에서 가져온대로 operator는 in을 쓰겠다 value가 하나이니 Equla도 될것이다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2088.png)

이딴 에러가 나오는데 들여쓰기가 틀려서 그런 게 대부분이다.

### 7.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2089.png)

어느 노드에 pod가 있냐 묻는다. 당연히 아까 설정한 node01이다

### 8.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2090.png)

지금까지의 총집합이다.

replica가 2이고 nginx 이미지를 가진 deployment red를 만들고  controlplane에만 배포하게 하란다.

[node-role.kubernetes.io/control-plane](http://node-role.kubernetes.io/control-plane)이 키를 이용하란다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2091.png)

우선 deployment를 생성한다 이제보니 replicas도 3으로 해버렸다. Node Affinity를 설정할 때 같이 수정하자

```jsx
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: node-role.kubernetes.io/control-plane
            operator: Exists
```

작성할 affinity다 키밖에 없으므로 Exists를 사용했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2092.png)

수정한 yaml이다. 마지막에 affinity를 쓰면 줄을 확인할 때 편하다.

# Taints and Tolerations vs Node Affinity

Taints와 Tolerations을 쓰면 원하는 Node에 해당 Pod만 배치되게 할 수 있지만 Pod이 다른 Node에 배치되는 것을 막을 수 없음

Node Affinity는 원하는 Pod이 해당 Node에 배치되게 살 수 있지만 다른 Pod도 Node에 배치 될 수 있음

Node와 Pod이 1:1로 Scheduling되게 하고 싶다면 둘 다 사용 해야 함

# Resource Requirements and Limits

node에는 마다 Cpu와 Memory가 할당되어있다.

당연하게도 Pod를 운영하려면 자원이 필요하다.

kube-scheduler는 Pod를 배치할 때 node의 자원을 고려하고 배치를 한다.

만약 모든 node에 자원이 없는 상태라면 kube-scheduler는 배포를 멈추고 Pending상태가 된다.

(이 상황에서 describe Event를 확인하면 Insufficient~를 확인 할 수 있다.)

CPU 숫자 1당 100m(밀리)를 의미함 그리고 이것은 AWS에서 vCPU(가상cpu)하나와 같음

+1 GCP Core, 1 Azure Core, 1 Hyperthread와 같음

Memmory는 mebibyte(메비 바이트)단위를 사용함

1 Gi(Gibibyte) = 1024 MiB(메비 바이트)이다.

1 Gigabyte = 1000 MB인 것에 비해 이진 수 기준인 것을 알 수 있다.

## Resource Limits

Pod 하나가 Node의 자원을 모두 차지하게 되면 다른 Pod에게도 영향을 줄 수 있다.

때문에 Pod에서 컨테이너가 소모할 수 있는 자원의 한계를 지정할 수 있다.

```yaml
piVersion: v1
kind: Pod
metadata:
  name: frontend
spec:
  containers:
  - name: app
    image: images.my-company.example/app:v4
    resources:
      requests:
        memory: "64Mi"
        cpu: "250m"
       ##이렇게 limits 항목 밑에 컨테이너가 소모할 수 있는 자원의 한계를 지정할 수 있다.##
      limits:
        memory: "128Mi"
        cpu: "500m"
  - name: log-aggregator
    image: images.my-company.example/log-aggregator:v6
    resources:
      requests:
        memory: "64Mi"
        cpu: "250m"
      limits:
        memory: "128Mi"
        cpu: "500m"
```

yaml파일로 보면 이러하다.

Pod에 할당 받은 자원은 시스템이 조절하기에 지정 받은 용량보다 더 사용할 수 없다.

하지만 Memory는 다르다 Memory는 지정 받은 양보다 자원을 더 많이 소비할 수 있고 계속해 limits보다 큰 자원을 소비하게 되면 Pod은 소멸하고 OOM(Out Of Memory)에러를 남긴다.

## Default Behavior

기본적으로 kubernetes는 resources request나 limits가 없다. 때문에 이런 상황에서는 어떤 Pod든지 자원을 많이 소비해 다른 Pod을 질식 시킬 수 있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2093.png)

첫 번째 예시는 Request와 Limits둘 다 없는 상태이다. 이 상황에서 request가 주어지지 않아 1번 Pod가 Node에 모든 자원을 사용하여 2번이 Pending 상태가 되었다.

ChatGpt에 물어본 결과

- **CPU**:
    - **request: 0** 으로 간주됩니다. (즉, 스케줄러는 이 Pod이 CPU 자원을 거의 안 쓰는 것처럼 인식)
    - **limit: 무제한 (unbounded)** → 노드에 할당된 전체 CPU를 사용할 수도 있음
- **Memory**:
    - **request: 0** 으로 간주됩니다.
    - **limit: 무제한 (unbounded)** → 필요 이상으로 메모리를 사용할 수 있음

이러한 상황이라고 한다.

두 번째 예시는 Limits만 존재하는 상태이다. 여기서 1번 Pod과 2번 Pod은 Request가 없어 모두 최대치까지 자원을 소비한다.

세 번째 케이스는 Request와 Limits모두 존재하는 상황으로 1번 Pod은 자원이 부족해 Lmits까지 사용하고 2번 Pod는 request로 보장되는 만큼만 자원을 소비했다.

마지막 예시는 Request만 사용하는 상태로 1번Pod이 Limits가 없어 가능한 자원을 소비했고 2번 Pod은 많은 자원이 필요 없어 Request가 보장하는 자원만 소비하였다. 뭄샤드는 이 예시가 제일 잘 사용했다 했다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2094.png)

메모리 예시인데 뭄샤드가 귀찮아서 cpu를 재활용했다. 다 비슷하지만 메모리일 때는 네 번째 상황에서 주의를 해야 한다. 메모리를 한번 할당하면 조절이 불가능하기 때문에 자원의 분배를 원하면 Pod를 종료해야 한다.

## LimitRange

그렇다면 공통으로 컨테이너에 request, limit를 정하려면 어떻게 할까

이것은 LimitRange를 사용하면 된다.

```yaml
apiVersion: v1
kind: LimitRange
metadata:
  name: resource-limits
  namespace: example
spec:
  limits:
  - type: Container
    default:
      cpu: "1"
      memory: "1Gi"
    defaultRequest:
      cpu: "500m"
      memory: "512Mi"
    min:
      cpu: "100m"
      memory: "128Mi"
    max:
      cpu: "2"
      memory: "2Gi"
```

이렇게 LimitRange를 정하면 Pod에서 컨테이너의 resource를 정하지 않았을 때 기본으로 적용이 된다

여기서 default, defaultRequest와 min, max 차이를 보면

| 항목 | 적용 대상 | 역할 | 자원을 명시하지 않았을 때 자동 설정? | 강제 제한 여부 |
| --- | --- | --- | --- | --- |
| `defaultRequest` | Container | **기본 request** 값 설정 | ✅ O (자동 적용) | ❌ (명시하면 override 가능) |
| `default` | Container | **기본 limit** 값 설정 | ✅ O (자동 적용) | ❌ (명시하면 override 가능) |
| `min` | Container | **최소값 제한** | ❌ X | ✅ (이보다 작으면 오류) |
| `max` | Container | **최대값 제한** | ❌ X | ✅ (이보다 크면 오류) |

이라고 한다. 때문에 사용 시기를 잘 생각해 사용하자

또한 LimitRange는 앞으로 만들어진 Pod에 대한 제한이므로 이미 만들어진 Pod에 대해서는 제한을 받지 않음

## Resource Quotas

Cluster에 배포된 앱의 자원을 제한하려면 Resource Quota를 사용해야한다.

Resource Quota는 특정 Namespace 안에서 사용할 수 있는 자원의 총량을 제한한다.

즉 Namespace 단위로 CPU, 메모리, 스토리지, 오브젝트 수(Pod, Service, PVC 등) 등을 최대 얼마나 사용할지 정해놓은 것이다.

```yaml
apiVersion: v1
kind: ResourceQuota
metadata:
  name: dev-quota
  namespace: dev
spec:
  hard:
    requests.cpu: "4"
    requests.memory: "8Gi"
    limits.cpu: "8"
    limits.memory: "16Gi"
    ##이런식으로 pod의 수도 제한을 걸 수 있다.
    pods: "10"
```

## Practice Test - Resource Requirements and Limits

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2095.png)

rabbit이라는 Pod가 배포되었다 CPU의 필요량을 알아내라

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2096.png)

가장 편한게 볼 수 있는 describe를 쓰자(k는 kubectl의 약자다)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2097.png)

Request를 보면 500m인 것을 알 수 있다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2098.png)

rabbit Pod를 지우라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%2099.png)

delete로 지우면 된다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20100.png)

elephant라는 pod이 배포되었다고 한다. 그런데 이 Pod이 실행이 실패된다는 데 이유를 찾아라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20101.png)

describe로 한번 훑어본다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20102.png)

이벤트를 읽어보면 마지막에 container mem-stress라는 컨테이너 때문에 BackOff되었다는 메세지를 볼 수 있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20103.png)

정확히 BackOff라는 항목이 없어 비슷한거로 했다 바로 틀린 것을 볼 수 있다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20104.png)

다시 스크롤을 올려서 Container로 가면 BackOff의 원인인 memstress를 볼 수 있고 그 밑에 보면 Last State 즉 마지막 상태를 볼 수 있다. 여기서 Terminated라는 사실을 알 수 있고 OOMKilled라는 원인을 볼 수 있다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20105.png)

OOMKilled는 메모리가딸려서 그렇다는 뜻인데pod의 memory  한계를 확인하라 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20106.png)

descirbe를 보면 최대는 10mi인것을 알 수 있다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20107.png)

elephant는 15Mi를 쓴다고 한다. 그래서 limit를 20까지 늘려라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20108.png)

edit로 elephant Pod의 메모리 최대값을 20으로 수정한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20109.png)

그럼 바로 터진다.

이는 이미 배포된 Pod라서 변경이 불가능하기 때문이다. 따라서

우리가 할 수 있는 방법은

1. Deployment수정
2. Pod지우고 다시 배포

위 두 가지 뿐이다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20110.png)

우선 -o yaml을 이용해 Pod의 yaml파일을 추출한다.

그리고 이 yaml을 바로 쓸 수 없어서 아래 항목을 모두 삭제해야 한다.

- `status`
- `metadata.resourceVersion`
- `metadata.uid`
- `metadata.creationTimestamp`
- `metadata.managedFields`
- `metadata.selfLink`
- `metadata.namespace` (필요시 유지 가능)
- `spec.nodeName` (자동 지정되는 필드)

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: elephant
  namespace: default
spec:
  containers:
  - args:
    - --vm
    - "1"
    - --vm-bytes
    - 15M
    - --vm-hang
    - "1"
    command:
    - stress
    image: polinux/stress
    imagePullPolicy: Always
    name: mem-stress
    resources:
      limits:
        memory: 20Mi
      requests:
        memory: 5Mi
    terminationMessagePath: /dev/termination-log
    terminationMessagePolicy: File
    volumeMounts:
    - mountPath: /var/run/secrets/kubernetes.io/serviceaccount
      name: kube-api-access-kfk6c
      readOnly: true
  dnsPolicy: ClusterFirst
  enableServiceLinks: true
  preemptionPolicy: PreemptLowerPriority
  priority: 0
  restartPolicy: Always
  schedulerName: default-scheduler
  securityContext: {}
  serviceAccount: default
  serviceAccountName: default
  terminationGracePeriodSeconds: 30
  tolerations:
  - effect: NoExecute
    key: node.kubernetes.io/not-ready
    operator: Exists
    tolerationSeconds: 300
  - effect: NoExecute
    key: node.kubernetes.io/unreachable
    operator: Exists
    tolerationSeconds: 300
  volumes:
  - name: kube-api-access-kfk6c
    projected:
      defaultMode: 420
      sources:
      - serviceAccountToken:
          expirationSeconds: 3607
          path: token
      - configMap:
          items:
          - key: ca.crt
            path: ca.crt
          name: kube-root-ca.crt
      - downwardAPI:
          items:
          - fieldRef:
              apiVersion: v1
              fieldPath: metadata.namespace
            path: namespace
```

위가 수정한 yaml이다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20111.png)

그리고 이를 이용해 삭제하고 만들면 된다.

### 6.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20112.png)

Pod이 실행 중인지 확인하라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20113.png)

돌아간다.

### 7.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20114.png)

pod을 지워라한다.

걍 `k delete pod elephant`를 실행하면된다.

# DaemonSets

우리는 지금까지 ReplicaSet이랑 Deployment를 이용해 Pod의 복사본을 배포할 수 있었다.

Demonset은 Replicaset이랑 비슷하다 여러 개의 Pod를 배포하게 한다.

다른 점은 Node 당 하나 씩 배포를 한다.

새로 Node가 추가되면 Demonset으로 설정한 Pod가 자동으로 새 노드에 배포된다.

즉 DemonSet은 모든 Node에 해당 Pod을 항상 배포한다.

DemonSet을 사용하는 예시

- Monitoring  Solution
- Logs Viewer

같은 노드에 필수적으로 필요한 요소를 배포할 때 쓴다 한다.

때문에 Node를 처음 생성할 때 DemonSet이 설정되어 있다면 기본 프로그램을 배포할 고민은 안 해도 된다.

또한 kube-proxy와 같은 worker node(뭔지 자세히 모름 master노드인가?)의 구성  요소도 DemonSets으로 배포할 수 있다.

Weave-net같은 Networking Solution을 사용할 때 에이전트가 각 노드에 필수로 배포되어야 한다. 그때 DemonSet으로 배포를 하면 편하다.

deamonset의 정의는 replicaset이랑 비슷하다.

yaml 예시를 보면

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: fluentd-elasticsearch
spec:
  selector:
    matchLabels:
      name: fluentd-elasticsearch
  template:
    metadata:
      labels:
        name: fluentd-elasticsearch
    spec:
      tolerations:
      - key: node-role.kubernetes.io/control-plane
        operator: Exists
        effect: NoSchedule
      - key: node-role.kubernetes.io/master
        operator: Exists
        effect: NoSchedule
      containers:
      - name: fluentd-elasticsearch
        image: quay.io/fluentd_elasticsearch/fluentd:v2.5.2
        resources:
          limits:
            memory: 200Mi
          requests:
            cpu: 100m
            memory: 200Mi
```

**ReplicaSet과 거의 동일한 구조이며, kind만 DaemonSet으로 변경되었다 볼 수 있다.**

selector의 라벨은 pod template의 라벨과 **일치**해야 합니다.

DaemonSet을 생성하려면

```bash
kubectl create -f daemonset.yaml
```

DaemonSet을 조회하려면:

```bash
kubectl get daemonset
```

DaemonSet의 자세한 정보를 보려면:

```bash
kubectl describe daemonset [이름]
```

이렇게 사용해야 한다.

그렇다면 deamonset은 어떻게 scheduling을 진행할까

맨 처음 manual scheduling 방식처럼 보면 `nodeName` 속성을 설정해 스케줄러를 우회하여 **직접 특정 노드에 Pod**했으나 이 방식은 Kubernetes 1.12 이전 버전까지만 사용했다.

그러나 **Kubernetes 1.12 버전 이후부터는**, DaemonSet도 기본 스케줄러와 **Node Affinity** 규칙을 사용하여 Pod를 각 노드에 자동으로 스케줄링할 수 있게 되었다.

## Practice Test - DaemonSets

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20115.png)

모든 namespace에서 데몬셋이 몇개냐 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20116.png)

`k get daemonset —all-namespace` 로 확인하니 두 개가 있는 걸 확인했다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20117.png)

어느 namespace에 kube-proxy 데몬셋이 있냐고 묻는다. 1번의 결과를 확인하면 kube-system에 있는 것을 알 수 있다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20118.png)

보기중에서 daemonset은 무엇인가 묻는다. 당연히 1번에서 확인 한 kube-flannel-ds다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20119.png)

몇개의 노드에 kube-proxy가 배포됬는지 묻는다.

`k describe daemonset kube-proxy --namespace=kube-system` 을 이용해 설명을 확인했다

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20120.png)

pod하나가 현재 실행 중이라는 것을 알 수 있다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20121.png)

kube-fannel-ds daemonset에서 pod을 배포할 때 어떤 이미지를 썼는지 묻는다.

1번의 결과에서 kube-fannel-ds가 kube-fannel namespace에 있다는 것을 알았으므로 

`k describe daemonset kube-flannel-ds --namespace=kube-flannel` 를 실행한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20122.png)

컨테이너를 확인하면 docekr.io/flannel/flannel:v0.23.0을 사용하는 것을 알 수 있다.

### 6.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20123.png)

FluentD Logging을 위한 데몬셋을 배포하라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20124.png)

파일을 보면 sample.yaml이 있다. 이것을 사용할 것이다.

먼저 vi 편집기로 sample.yaml에 들어간다.

다음 공식문서 [https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/)에서 예시를 긁어 필요한(아는)것만 남긴다.

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: elasticsearch
  namespace: kube-system
spec:
  selector:
    matchLabels:
      name: elasticsearch
  template:
    metadata:
      labels:
        name: elasticsearch
    spec:
      containers:
      - name: fluentd-elasticsearch
        image: registry.k8s.io/fluentd-elasticsearch:1.20
```

다음 k create -f sample.yaml로 daemonset을 생성했다.

# Static Pods

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20125.png)

kubelet은 자신의 노드에서 어떤 Pod이 실행되어야 하는지 kube-apiserver한테 지시를 받는다.

이 지시는 kube-scheduler가 정하고 이 기록은 ETCD Cluster에 저장된다.

**그런데 이런 요소들이 전혀 없다고 가정해보자:**

- kube-apiserver도 없고
- kube-scheduler도 없으며
- controller도 없고
- ETCD 클러스터도 없다.

즉, 마스터 노드 자체가 존재하지 않고 클러스터에 소속되지 않은 단독 노드 한 개만 존재하는 상황이다.

이 상황에서 kubelet은 단독으로 pod를 실행할 수 있을까? 있다면 어디서 지시를 받아야 할까

이 경우 api대신 kubelet에게 직접 Pod정의 파일(yaml 파일)을 제공해 Pod을 실행 할 수 있다.

**kubelet은 특정 디렉터리를 주기적으로 확인해서 거기에 있는 YAML 파일(Pod 정의) 을 읽고 Pod를 생성합니다.**

이 디렉터리에 파일을 **추가**하면 Pod가 생성되고, 파일을 **수정**하면 Pod가 다시 생성되며, 파일을 **삭제**하면 Pod도 자동으로 삭제됩니다.

이렇게 **API 서버 없이 kubelet이 자체적으로 만드는 Pod를 "Static Pod (정적 Pod)"** 라고 한다.

**⚠️ 중요한 점**

- 이 방식으로는 **Pod만 생성**할 수 있다.
- ReplicaSet, Deployment, Service 같은 오브젝트는 만들 수 없습니다.
    
    → 이들은 Kubernetes 전체 아키텍처(컨트롤러 등)의 개념이기 때문이다.
    

kubelet은 **오직 Pod 수준에서만 작동**하므로 static Pod만 이해할 수 있다.

**🔧 static Pod 설정 방법**

- kubelet을 실행할 때 kubelet.service  `--pod-manifest-path` 옵션으로 해당 디렉터리 경로를 지정할 수 있습니다.
    
    예: `--pod-manifest-path=/etc/kubernetes/manifests`
    
- 또는 설정 파일(config 파일)을 별도로 사용해서 `staticPodPath` 속성을 지정할 수도 있습니다.
예: kubelet.service에 `—config=kubeconfig.yaml` 이란 설정을 추가하고
      kubeconfig.yaml파일에 `statifcPodPath: /etc/kubernetes/manifests` 같은 예로 설정을 지정할 수 있다.

**📌 설정 확인 팁:**

1. `kubelet.service` 파일에서 `-pod-manifest-path`가 있는지 확인.
2. 없다면 `-config` 옵션이 있는지 확인.
3. config 파일 내에서 `staticPodPath` 항목을 찾기.

**🔍 static Pod 실행 상태 보기**

- 클러스터가 아직 없으므로 `kubectl` 명령어는 사용 불가
- 따라서 `docker ps`(cri-o는 crictl ps, containerd는 nerdctl ps) 등 Docker 명령어로 상태를 확인합니다.

**🤔 클러스터에 소속된 노드(kube-apiserver 가 존재할 때)에서는 어떻게 될까?**

- kubelet은 다음 **두 가지 입력 방식**으로 Pod를 생성할 수 있습니다:
    1. static Pod 디렉터리에서 YAML 파일 읽기
    2. kube-apiserver를 통한 HTTP API 호출

→ 두 방식 모두 동시에 사용할 수 있다.

**🤝 API 서버는 static Pod를 인식할까?**

- 네, 인식합니다.
- kubelet은 static Pod를 만들면서 **kube-apiserver에 read-only mirror 객체**도 같이 생성합니다.
- `kubectl get pods` 명령어로 해당 static Pod를 볼 수 있습니다.
- 하지만 이 Pod는 **수정하거나 삭제할 수 없고**, 오직 **디렉터리에서(menifest 폴더) 파일(yaml)을 수정/삭제**해야 반영됩니다.
- 이 static Pod 이름에는 자동으로 노드 이름이 붙습니다. 예: `pod-name-node01`

**🛠️ static Pod는 언제 쓰나요?**

static Pod는 Kubernetes 컨트롤 플레인 자체를 **Pod 형태로 실행**하기 위해 사용됩니다.

예:

1. 모든 마스터 노드에 kubelet 설치
2. API 서버, Controller, ETCD 등의 컨트롤 플레인 컴포넌트를 Pod로 정의
3. `/etc/kubernetes/manifests` 디렉터리에 YAML 파일 배치

→ kubelet이 이 컴포넌트들을 static Pod로 실행하게 됩니다.

이 방식은 `kubeadm`으로 클러스터를 구성할 때 자동으로 사용됩니다

**❓ static Pod와 DaemonSet의 차이점**

---

| 항목 | static Pod | DaemonSet |
| --- | --- | --- |
| 생성 주체 | kubelet | DaemonSet 컨트롤러 (kube-apiserver) |
| 클러스터 필요 여부 | 필요 없음 | 클러스터 필요 |
| 스케줄링 대상 | 각 노드별 직접 실행 | 각 노드별 1개씩 |
| 삭제/수정 방법 | manifest 디렉터리 파일 수정 | kubectl edit/delete |
| kube-scheduler 관여 | ❌ 없음 | ❌ 없음 |

## Practice Test - Static Pods

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20126.png)

클러스터 안의 모든 namespace에 pod이 몇 개냐 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20127.png)

`k get pods -A wide -o`  로 보니 10개 중에서 4개의 pod이 뒤에 node이름을 달고 있다.

정확한 방법 

`kubectl get pod kube-apiservercontrolplane -n kube-system -o yaml` 을 이용해 yaml에 접속해

ownerReferences: 를 확인한다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20128.png)

아래의 컴포넌트 중에서 static pod이 아닌 걸 고르라고 한다. 1번결과를 보면 coredns 빼고 다 static pod다

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20129.png)

2번과 같은 질문이다.

kube-proxy가 아니다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20130.png)

어떤 노드에 static pod이 생성되었냐 묻는다. controlplane밖에 없다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20131.png)

어느 디렉토리가 pod을 정의하는 곳이냐 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20132.png)

`ps -aux | grep config`를 실행해 config의 경로를 찾았다.(뭄샤드는 `ps -aux | grep /usr/bin/kubelet`을 이용했다.)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20133.png)

`cat /var/lib/kubelet/config.yaml`

를 실행해 staticPodPath로 경로를 찾았다.

### 6.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20134.png)

여기 디렉토리에 pod 정의 파일이 몇개가 있냐 묻는다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20135.png)

ls로 확인하니 4개가 나왔다.

### 7.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20136.png)

kube-api server에 쓰는 이미지지가 뭐냐 묻는다.

`cat /etc/kubernetes/manifests/kube-apiserver.yaml` 로 내부를 확인하면

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20137.png)

이걸 쓴다고 한다.

### 8.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20138.png)

static-busybox라는 pod을 만들라고 한다.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: static-busybox
spec:
  containers:
    - name: busybox
      image: busybox
      command: ["sleep","1000"]
```

menifest디렉토리 안에 이런 yaml을 만들었다.

yaml을 만들면 바로 static pod이 생성된다.

### 9.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20139.png)

pod의 이미지를 고쳐라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20140.png)

한줄 고친다.

### 10.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20141.png)

static-green-box라고 하는 static pod을 지우라고 한다.

 

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20142.png)

k get pod -A로 확인하면 node01에 있다고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20143.png)

우리는 controlplane에 있으므로 node01로 이동한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20144.png)

`ps -aux | grep config` 로 확인하면 /var/lib/kubelet/config.yaml에 있다고 한다.

이걸 cat을 이용해 확인하면

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20145.png)

이런 이상한 경로가 staticpath라고 한다.

`cd /etc/just-to-mess-with-you` 로 이동하고 ls로 확인하면

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20146.png)

찾았다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20147.png)

이제 이걸 지우면 된다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20148.png)

마지막으로 node01에 나가서 확인하면 종료다.

# Priority Class

### ✅ **기본 개념**

- 쿠버네티스에서는 다양한 애플리케이션들이 **Pod**로 실행됩니다.
- 이들 애플리케이션은 **서로 다른 우선순위**를 가질 수 있습니다.
- 예를 들어, 쿠버네티스 **컨트롤 플레인 구성 요소들**도 클러스터 내에서 Pod로 실행되며, 어떤 상황에서도 **항상 실행되어야 합니다**.
- 마찬가지로, 데이터베이스 같은 **중요 애플리케이션**은 반드시 실행되어야 하고,
- 반면 **백그라운드 작업 같은 낮은 우선순위의 작업**도 존재합니다.

---

### ✅ **우선순위 클래스(Priority Class)의 역할**

- **우선순위 클래스**는 높은 우선순위의 작업이 **낮은 우선순위 작업보다 우선적으로 스케줄링**되도록 해줍니다.
- 만약 **높은 우선순위의 Pod**가 스케줄링되지 못하면, **낮은 우선순위의 Pod를 종료**시켜서 자리를 확보할 수도 있습니다.

---

### ✅ **우선순위 클래스의 특성**

- **Namespace에 속하지 않는(non-namespace) 객체**입니다.
    - 따라서 한 번 생성되면 **모든 namespace의 Pod에서 사용 가능**합니다.
- 우선순위 값은 **숫자 범위**로 정의됩니다.
    - 일반 애플리케이션: `+10억 ~ -20억` (음수일수록 낮은 우선순위, 양수일수록 높은 우선순위)
    - 시스템 중요 구성요소(예: 컨트롤 플레인): **+20억까지** 우선순위를 가질 수 있습니다.

---

### ✅ **기존 우선순위 클래스 조회**

```bash
kubectl get priorityclass

```

- 예시: `system-cluster-critical`, `system-node-critical` 클래스가 있으며,
- 이들은 보통 `+20억` 근처의 높은 우선순위 값을 가집니다.

---

### ✅ **우선순위 클래스 생성 방법**

- 다음과 같은 YAML 파일로 생성합니다:

```yaml
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata:
  name: high-priority
value: 1000000
description: "High priority class for critical apps"

```

- 생성 후, Pod yaml파일에서 아래처럼 참조합니다:

```yaml
spec:
  priorityClassName: high-priority

```

---

### ✅ **기본 우선순위 설정 (default priority)**

- **priorityClassName을 명시하지 않은 경우**, 기본 우선순위는 `0`입니다.
- **기본값을 변경하고 싶다면**, `globalDefault: true` 속성을 가진 우선순위 클래스를 하나 지정할 수 있습니다.
    - 단, **globalDefault는 오직 하나의 PriorityClass만 가질 수 있습니다.**

---

### ✅ **우선순위와 스케줄링 및 Preemption**

- 예시:
    - **critical app**: 우선순위 7
    - **jobs app**: 우선순위 5
    - → critical app이 먼저 배치되고, 자원이 남으면 jobs app도 배치됨
- 자원이 꽉 찬 상태에서 **우선순위 6의 새로운 Pod**가 들어오면?
    - **기본적으로는** 낮은 우선순위의 Pod를 **종료(preempt)**시키고 새로운 Pod가 배치됨
    - 이 동작은 priority class의 yaml파일에  `preemptionPolicy` 속성으로 제어 가능
        - `PreemptLowerPriority`: 기본값, 낮은 우선순위 Pod 종료
        - `Never`: 기존 Pod를 종료하지 않고 **자원이 생길 때까지 대기**

---

### ✅ **Preemption 정책 정리**

| 정책 | 동작 요약 |
| --- | --- |
| `PreemptLowerPriority` (기본값) | 낮은 우선순위 Pod를 종료하고 높은 우선순위 Pod를 배치 |
| `Never` | 기존 Pod를 종료하지 않고, 자원이 생길 때까지 큐에서 대기 |

## Practice Test - Priority Classes

### 1.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20149.png)

priority class중에 기본 쿠버네티스의 설정에 포함되는 곳을 물어본다.

`k get priorityclass` 를 실행하면

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20150.png)

이런 상황이 나오고 system-cluster-critical 만 맞다는 것을 알 수 있다.

### 2.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20151.png)

system-node-critical의 우선순위 값이 얼마냐 묻는다.

1번에 나온 대로 한다면 2000001000이다.

### 3.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20152.png)

system-node-critical의 preemptionPolicy를 묻는 다. 1번에서 보면 PreemptLowerPriority라는 것을 알 수 있다.

### 4.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20153.png)

high-priority 라는 priority class를 만들라고 한다.

```yaml
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata:
  name: high-priority
value: 100000
preemptionPolicy: PreemptLowerPriority
globalDefault: false
```

이 yaml을 작성하고

create를 이용해 priorityclass를 생성하면 된다.

### 5.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20154.png)

low-priority라는 priorityclass를 만들라고한다.

```yaml
apiVersion: scheduling.k8s.io/v1
kind: PriorityClass
metadata:
  name: low-priority
value: 1000
globalDefault: false
```

위와 같은 yaml파일을 생성하면된다.

### 6.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20155.png)

기본 namespace에서 low-priority priorityclass를 선택한 nginx image를 쓰는 pod을 만들라한다.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: low-prio-pod
spec:
  containers:
  - name: nginx
    image: nginx
  priorityClassName: low-priority
```

위 yaml파일로 pod을 만들면 된다.

### 7.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20156.png)

high-priority를 priorityclass로 사용하는 다른  pod를 만들라고한다.

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: high-prio-pod
spec:
  containers:
  - name: nginx
    image: nginx
  priorityClassName: high-priority
```

위 yaml을 이용해 pod을 만들면 된다.

### 8.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20157.png)

이걸로 만든 pod들의 우선순위를 볼 수 있다고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20158.png)

확인했다.

### 9.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20159.png)

환경에 두 개의 pod을 배포했는데 상태를 보라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20160.png)

critical-app은 pending되었고 low-app은 실행중이다.

### 10.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20161.png)

low-app이 리소스를 많이 먹어서 critical-app이 pendign상태라고 한다. describe로 확인하라 한다.

### 11.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20162.png)

critical-app에 high-priority를 할당하고 이 pod을 지우고 다시 깔아라고 한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20163.png)

`k get pod critical-app -o yaml > critical-app.yaml` 를 실행시켜 critical-app.yaml을 추출한다.

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20164.png)

critical-app.yaml의 spec에 priorityclass항목을 추가한다.(밑에 priority라는 항목은 꼭 지워야한다)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20165.png)

![image.png](Ch3_Scheduling%201f8cda69b1438095a7abc73ce377b395/image%20166.png)

pod을 지우고 만들면 끝난다.

# Multiple Schedulers

### ✅ 기본 스케줄러 이해

- 쿠버네티스는 기본적으로 **default-scheduler**를 통해 파드를 자동 배치함.
- **Taints, Tolerations, Node Affinity** 등을 고려해 스케줄링 수행.

---

### ✅ 왜 여러 스케줄러가 필요할까?

- 특정 애플리케이션에 대해 **고유한 조건이나 로직**으로 스케줄링을 하고 싶을 때.
- 쿠버네티스는 확장 가능하므로, **사용자 정의 스케줄러(Custom Scheduler)**를 추가할 수 있음.

---

### 🛠️ 사용자 정의 스케줄러 구성 방법

1. **스케줄러 이름 설정**
    - 기본 스케줄러: `default-scheduler`
    - 사용자 스케줄러: 설정 파일에서 `schedulerName: my-scheduler` 등으로 명시
2. **스케줄러 실행 방식**
    - ⬛ **바이너리 직접 실행**: `kube-scheduler` 명령어로 별도 실행 (현대적 방법 아님)
    - 🟦 **Pod 또는 Deployment로 실행**: 대부분의 경우 사용하는 방식
3. **설정 파일 구성 예시**
    
    ```yaml
    apiVersion: kubescheduler.config.k8s.io/v1
    kind: KubeSchedulerConfiguration
    schedulerName: my-scheduler
    leaderElection:
      leaderElect: false
    ```
    
    ```yaml
    apiBersion: v1
    kind: Pod
    metadata:
    	name: my-custom-scheduler
    	namespace: kube-system
    spec:
    	containers:
    	- command:
    		- kube-scheduler
    		image: k8s.gcr.io/kube-scheduler-amd64:v1.11.3
    		name: kube-scheduler
    ```
    
4. **ConfigMap을 사용한 설정 전달**
    - 설정 파일을 ConfigMap으로 만들고 Volume으로 마운트해 스케줄러에 주입
5. **HA 환경에서는 `leaderElect: true` 사용**
    - 여러 스케줄러 인스턴스 중 하나만 리더가 되어 작동

---

### 📦 사용자 스케줄러로 파드 실행하기

- 파드 정의 파일에 다음 필드 추가:
    
    ```yaml
    spec:
      schedulerName: my-scheduler
    ```
    

---

### 🧐 상태 확인 및 디버깅 팁

- 파드가 `Pending` 상태일 경우:
    - `kubectl describe pod <pod명>`로 스케줄링 오류 확인
- 어떤 스케줄러가 작동했는지 확인:
    - `kubectl get events -o wide`
- 스케줄러 로그 보기:
    - `kubectl logs <스케줄러-파드명> -n kube-system`