# Ch 6_Cluster Maintenance(3/3)

사람: Dahui Kim
완료 여부: Yes
작성일: 2025년 6월 21일
주차: 4주차

## 1정리

### **백업 시 고려할 요소**

1. **etcd 클러스터**
    - 클러스터의 모든 상태 정보가 저장되어 있음.
    - 주요 백업 대상.
2. **Persistent Storage**
    - 애플리케이션이 사용하는 영속적 스토리지도 백업 대상.
3. **Kubernetes 리소스 정의 파일**
    - Deployment, Pod, Service 등의 정의 파일을 사용해 생성한 리소스는 반드시 저장.
    - **선언적(Declarative)** 방식은 구성 파일이 있어 재사용과 공유가 용이.
    - 파일은 GitHub과 같은 **소스 코드 저장소에 백업**하는 것이 좋음.
4. **명령어(Imperative) 방식으로 생성한 리소스**
    - 예: kubectl create 명령어로 생성한 namespace, secret, configmap 등.
    - 파일로 기록되지 않았을 가능성 있음 → API 서버에서 직접 쿼리해 백업 필요.

### **Kubernetes 리소스 백업 방법**

- kubectl get all --all-namespaces -o yaml 명령을 사용해 모든 리소스를 YAML로 추출하여 저장.
- 이를 자동화한 스크립트 사용 가능.
- **Velero**(구 Ark)와 같은 도구를 사용하면 자동으로 백업/복구 가능.

### **etcd 백업 및 복구 방법**

1. **백업**
    - etcdctl snapshot save snapshot.db 명령어로 스냅샷 생성.
    - 원하는 디렉토리 지정 가능.
    - 인증을 위해 --cert, --key, --cacert, --endpoints 등의 옵션 필요.
2. **백업 상태 확인**
    - etcdctl snapshot status snapshot.db
3. **복구**
    - Kube API 서버 중지
    - etcdctl snapshot restore snapshot.db --data-dir=/var/lib/etcd-from-backup
    - etcd 설정 파일에서 새 데이터 디렉토리 지정
    - 서비스 재시작: systemctl daemon-reexec, systemctl restart etcd, systemctl start kube-apiserver

> 복구 시 etcd는 새로운 클러스터로 초기화되며, 기존 클러스터에 잘못 연결되지 않도록 설계되어 있음.
> 

### **어떤 방법을 선택할까?**

- **etcd 백업**
    - 전체 클러스터 상태를 저장하므로 포괄적.
    - 그러나 관리형 Kubernetes에서는 접근 제한 가능.
- **Kube API 서버 백업**
    - 리소스 정의만 백업하지만, 관리형 환경에서도 사용 가능.

### **결론**

- 선언적 방식으로 만든 구성 파일은 소스 코드 저장소에 보관.
- imperative 방식으로 생성된 리소스는 API 서버에서 쿼리해서 백업.
- etcd 백업은 클러스터 전체 복구에 유용.
- 상황에 따라 적절한 방법을 선택할 것.
1. What is the version of ETCD running on the cluster?
Check the ETCD Pod or Process

---

### **개요**

- etcdctl: **실행 중인 etcd 서버와 통신**하여 스냅샷을 생성하거나 상태를 조회하는 CLI.
- etcdutl: **오프라인 백업 및 복원** 작업을 수행하는 CLI.

### **🔍 etcdctl 사용법 (스냅샷 기반 백업)**

**버전 확인**

```bash
etcdctl version
```

**백업 (스냅샷 생성)**

```bash
ETCDCTL_API=3 etcdctl \
  --endpoints=https://127.0.0.1:2379 \
  --cacert=/etc/kubernetes/pki/etcd/ca.crt \
  --cert=/etc/kubernetes/pki/etcd/server.crt \
  --key=/etc/kubernetes/pki/etcd/server.key \
  snapshot save /backup/etcd-snapshot.db
```

**옵션 설명:**

- -endpoints: etcd 서버 주소 (https://127.0.0.1:2379)
- -cacert: CA 인증서 경로
- -cert: 클라이언트 인증서 경로
- -key: 클라이언트 키 경로

### **📊 스냅샷 상태 확인**

```bash
etcdctl snapshot status /backup/etcd-snapshot.db --write-out=table
```

- 스냅샷의 **크기, revision, 해시, key 개수** 등을 보여줌
- 복구 전에 무결성 확인 용도로 유용

### **💾 etcdutl 사용법 (파일 기반 백업/복원)**

**📦 백업 (오프라인)**

```bash
etcdutl backup \
  --data-dir /var/lib/etcd \
  --backup-dir /backup/etcd-backup
```

- etcd의 데이터와 WAL 파일을 복사 (etcd가 실행 중이지 않아야 함)

**🔁 복원**

- 스냅샷 복원

```bash
etcdutl snapshot restore /backup/etcd-snapshot.db \
  --data-dir /var/lib/etcd-restored
```

- 파일 복사 복원
    - etcdutl backup으로 생성한 폴더의 내용을 다시 /var/lib/etcd로 복사
    - etcd 재시작

### **✅ 정리**

| **기능** | **도구** | **명령어 유형** | **실행 상태** |
| --- | --- | --- | --- |
| 스냅샷 백업 | etcdctl | snapshot save | 실행 중 etcd 필요 |
| 스냅샷 상태 확인 | etcdctl | snapshot status | - |
| 스냅샷 복원 | etcdutl | snapshot restore | 오프라인 복구 |
| 파일 기반 전체 백업 | etcdutl | backup | etcd 중지 필요 |
| 파일 기반 복원 | etcdutl | 백업 디렉토리 복사 + etcd 재시작 | etcd 중지 필요 |

---

1. We have a working Kubernetes cluster with a set of web applications running. Let us first explore the setup. How many deployments exist in the cluster in `default`namespace?
    
    ```bash
    k get deploy
    ```
    
2. What is the version of ETCD running on the cluster? Check the ETCD Pod or Process
    
    ```bash
    etcdctl version //보통 etcd 와 일치하지만 다를 수도 있음
    ```
    
    ```bash
    kubectl get pods -n kube-system
    k describe pod etcd-controlplane -n kube-system | grep -i image //생성에 사용한 이미지 명 확인
    ```
    
3. At what address can you reach the ETCD cluster from the controlplane node?
    
    ```bash
    k describe pod etcd-controlplane -n kube-system | grep -i url
    //--listen-client-urls
    //k describe pod etcd-controlplane -n kube-system | grep  '\--listen-client-
    urls' 라고 안내하고 있지만 잘모르니깐...
    ```
    
4. Where is the ETCD server certificate file located? Note this path down as you will need to use it later
    - **왜 etcd에 인증서가 필요한가?**
        1. **통신 암호화 (TLS)**
            - etcd는 기본적으로 https:// 프로토콜을 사용
            - 클라이언트와 서버 간의 데이터가 **암호화되지 않으면**, 중간에 데이터가 탈취될 수 있음
            - 인증서는 이 데이터를 **암호화하고 보호**
        2. **서버 인증**
            - 클라이언트(etcdctl 등)는 접속 대상이 **진짜 etcd 서버인지** 확인
            - server.crt 인증서는 서버의 신원을 증명
        3. **클라이언트 인증 (Mutual TLS)**
            - etcd는 **접속하는 클라이언트의 인증서도 검증**
            - 즉, etcd에 접근하려면 **CA가 발급한 인증서**를 가진 클라이언트여야만함
                
                > 이를 **Mutual TLS (mTLS) 라고 하며, 양방향 인증이 이루어짐**
                > 
        4. 사용되는 인증서
            
            
            | **인증서 파일** | **설명** |
            | --- | --- |
            | ca.crt | 인증서들을 발급한 CA(Certificate Authority) |
            | server.crt | etcd 서버의 인증서 (서버의 신원 증명) |
            | server.key | 서버 인증서에 대한 개인 키 |
            | peer.crt | etcd 노드 간 통신(peer 간 통신)용 인증서 |
            | peer.key | peer 인증서의 개인 키 |
            | client.crt (옵션) | etcd에 접근하는 클라이언트 인증서 |
            | client.key (옵션) | 클라이언트의 개인 키 |
    
    ```bash
    k describe pod etcd-controlplane -n kube-system | grep -i cert
    ///etc/kubernetes/pki/etcd/server.crt
    ```
    
5. Where is the ETCD CA Certificate file located? Note this path down as you will need to use it later.
    
    ```bash
    k describe pod etcd-controlplane -n kube-system | grep -i ca
    ```
    
6. The controlplane node in our cluster is planned for a regular maintenance reboot tonight. While we do not anticipate anything to go wrong, we are required to take the necessary [backups](https://kubernetes.io/docs/tasks/administer-cluster/configure-upgrade-etcd/#backing-up-an-etcd-cluster). Take a [snapshot](https://kubernetes.io/docs/tasks/administer-cluster/configure-upgrade-etcd/#volume-snapshot) of the ETCD database using the built-in snapshot functionality. Store the backup file at location `/opt/snapshot-pre-boot.db`
    
    ```bash
    ETCDCTL_API=3 etcdctl --endpoints=https://127.0.0.1:2379 \
      --cacert=<trusted-ca-file> \
      --cert=<cert-file> \
      --key=<key-file> \
      snapshot save <backup-file-location>
      
    ETCDCTL_API=3 etcdctl --endpoints=https://127.0.0.1:2379 \
      --cacert=/etc/kubernetes/pki/etcd/ca.crt \
      --cert=/etc/kubernetes/pki/etcd/server.crt \
      --key=/etc/kubernetes/pki/etcd/server.key \
      snapshot save /opt/snapshot-pre-boot.db
    ```
    
7. Great! Let us now wait for the maintenance window to finish. Go get some sleep. (Don't go for real) Click `Ok` to Continue
8. Wake up! We have a conference call! After the reboot the master nodes came back online, but none of our applications are accessible. Check the status of the applications on the cluster. What's wrong?
    
    ```bash
    k get po
    k get deploy
    k get svc
    ```
    
9. Luckily we took a backup. Restore the original state of the cluster using the backup file.
    
    ```bash
    etcdutl --data-dir <data-dir> snapshot restore /opt/snapshot-pre-boot.db
    // 위치 확인
    ps -ef | grep kubelet
    //--pod-manifest-path 확인, 만약 --config 있다면 해당 설정 파일 확인
    cat /var/lib/kubelet/config.yaml | grep staticPodPath
    //staticPodPath 확인 -> grep으로 수행
    ls /etc/kubernetes/manifests
    cat /etc/kubernetes/manifests/etcd.yaml
    cat /etc/kubernetes/manifests/etcd.yaml | grep '\--data-dir'
    
    //기존 경로와 다른 경로 지정
    etcdutl --data-dir /var/lib/etcd-from-backup snapshot restore /opt/snapshot-pre-boot.db
    //menifest/etcd.yaml 파일에서 hostPath가 새로운 경로를 가리키도록 수정
    //watch crictl ps (단순 재시작 확인용)
    
    k get deploy,svc //동시 조회, 공백이 있으면 조회안됨
    ```