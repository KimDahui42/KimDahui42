# Ch 6_Cluster Maintenance(1/3)

사람: Dahui Kim
완료 여부: Yes
작성일: 2025년 6월 9일
주차: 2주차

안전하게 종료하는 방법

“cordon” → 스케쥴 불가능 상태로 설정하는 명령

- 새로운 파드가 해당 노드에 배치되지 않는다.
- 이미 실행 중인 파드는 그대로 유지
- 새 파드 차단

“drain”

- 노드를 비우고(evict)
- 모든 파드를 퇴거(drain)

### Practice Tests - OS Upgrades

1. node chk
    
    ```bash
    k get nodes
    ```
    
2. How many applications do you see hosted on the cluster? 
    1. default 네임스페이스 기준
    
    ```bash
    k get deployments
    ```
    
3. Which nodes are the applications hosted on?
    1. 옵션에 따라 보이는 항목이 다름(IP, Node)
        
        ![image.png](Ch%206_Cluster%20Maintenance(1%203)%20202cda69b14380658eb3e106156c5143/image.png)
        
    
    ```bash
    k get pod -o wide
    ```
    
4. We need to take `node01` out for maintenance. Empty the node of all applications and mark it unschedulable.
    1. kubectl drain의 역할
        1. 해당 node를 cordon 상태(unschedulable)로 설정
        2. node를 안전한 상태로 퇴거(evict)
        3. —ignore-daemonsets의 경우 daemonset은 한 개씩 유지되어야하기 때문에 다시 살아나고 이는 무한 루프 상태에 빠지게할 수 있어 미리 무시하는 옵션을 제공하는 것
    
    ```bash
    k drain node01 --ignore-daemonsets 
    ```
    
5. What nodes are the apps on now?
    
    ```bash
    k get po -o wide
    ```
    
6. The maintenance tasks have been completed. Configure the node `node01` to be schedulable again.
    1. kubectl uncordon 명령은 cordon 상태(unschedulable)를 schedulable하게 회복
    
    ```bash
    k uncordon node01
    ```
    
7. How many pods are scheduled on `node01` now in the default namespace?
    1. -o wide 옵션은 어떤 노드에 파드가 스케줄되어 있는지(NODE 열) 나타냄
    2. 실제 예정(scheduled)된 pod를 확인해야하기 때문에 nominated node 항목을 확인
    
    ```bash
    k get po -o wide
    ```
    
8. Why are there no pods on `node01`?
    1. Uncordon 명령어로는 파드를 받을 수 있는 상태로 표시만 하는 것이지, 자동으로 파드를 바로 그 노드에 다시 스케줄하거나 배치하는 것이 아님
    2. 새로운 pod가 생성될때만 scheduled된다
9. Why are the pods placed on the `controlplane` node?
    1. taints가 없기 때문
    
    ```bash
    k describe node controlpane
    ```
    
10. Time travelling to the next maintenance window… ⇒ 환경 변경
11. We need to carry out a maintenance activity on `node01` again. Try draining the node again using the same command as before: `kubectl drain node01 --ignore-daemonsets`
12. Why did the drain command fail on `node01`? It worked the first time!
    1. kubectl drain 명령어는 기본적으로 **컨트롤러(controller)가 없는 파드**는 삭제하지 않음
        1. 직접 kubectl run으로 만든 단일 파드이거나, 관리 대상이 아닌 수동 파드
    2. 단일 파드이기 때문에 replicaset의 관리 대상이 아님
    
    ```bash
    k get po -o wide
    ```
    
13. What is the name of the POD hosted on `node01` that is not part of a replicaset?
    
    ```bash
    k get po -o wide
    ```
    
14. What would happen to `hr-app` if `node01` is drained forcefully?
    
    ```bash
    k drain node01 --ignore-daemonsets --force
    ```
    
15. Oops! We did not want to do that! `hr-app` is a critical application that should not be destroyed. We have now reverted back to the previous state and re-deployed `hr-app` as a deployment.
16. `hr-app`is a critical app and we do not want it to be removed and we do not want to schedule any more pods on `node01`. Mark `node01` as `unschedulable` so that no new pods are scheduled on this node.
    
    ```bash
    k cordon node01
    k get po -o wide
    ```