# ch 7_security_인증 및 TLS(1/4)

사람: 김형민
완료 여부: Yes
작성일: 2025년 6월 17일
주차: 4주차

## 1. 🛡️ Host 보안

- 쿠버네티스 클러스터를 구성하는 **노드(물리/가상 서버)** 자체가 공격당하면, 클러스터 전체가 위험해진다.
- 따라서 다음과 같은 **기본적인 시스템 보안 조치가** 필요하다.
    - 루트 계정 접근 제한
    - SSH 포트 접근 제어
    - 비밀번호 로그인 비활성화 → **SSH 키 기반 로그인만 허용**
    - OS 보안 패치 최신 상태 유지
    - 불필요한 서비스 제거

✅ **실제 해킹의 대부분은 Host 수준에서 시작되므로, 클러스터 보안의 가장 첫 단계는 Host 보안이다.**

## 2. 🔐 Kubernetes API 서버 보안

### ✔️ kube-apiserver는?

- 클러스터의 **모든 리소스를 관리하는 핵심 제어 지점**
- `kubectl`, Dashboard, 외부 앱 등 **모든 접근은 반드시 API 서버를 통해서만 가능**

### ✔️ API 서버 접근 보안의 두 축

1. **인증(Authentication)**
    
    → 이 요청이 **"누구인지"** 확인
    
2. **권한 부여(Authorization)**
    
    → 이 사용자가 **무엇까지 할 수 있는지** 결정
    

## 3. 👥 인증(Authentication) 방식

> 인증은 API 서버가 **“누구인지 식별하는 절차”**
> 

### ✅ 주요 인증 방식 요약

| 인증 방식 | 설명 | 보안 수준 |
| --- | --- | --- |
| **정적 파일 (ID/비밀번호, 토큰)** | CSV 형태로 사용자 관리 | 🔸 낮음 (테스트 용도) |
| **인증서(Certificate)** | 사용자에게 클라이언트 인증서 발급 | ✅ 높음 |
| **LDAP/OIDC/Kerberos 등 외부 연동** | 사내 인증 시스템 연동 | ✅ 높음 |
| **서비스 계정(ServiceAccount)** | 파드 등 앱이 사용할 계정 | ✅ 높음 (자동 토큰 발급) |

### API 서버를 통한 인증 과정

> 모든 사용자 접근은 **`kube-apiserver`**를 통해 이루어진다.
> 

![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn.png)

- kubectl 또는 API 직접 접근 둘다 모두 API 서버를 거치게 된다.
- API 서버는 요청을 처리하기전에 인증과정을 거친다.

### 인증 방식

> 쿠버네티스 API 서버는 다양한 인증 메커니즘을 지원함
> 

![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%201.png)

- **1. 정적 비밀번호 파일 기반 인증 방식**
    
    > 
    > 
    > 
    > ![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%202.png)
    > 
    > 1. **사용자 정보 csv 파일을 생성**
    >     - 비밀번호, 사용자 이름, 사용자 ID를 쉼표로 구분하여 CSV 파일에 저장한다.
    >     - 선택적으로 네 번째 열에 그룹 정보를 추가하여 사용자를 특정 그룹에 할당할 수 있다.
    > 
    > ![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%203.png)
    > 
    > 1. **API 서버 설정**
    >     
    >     ```bash
    >     —basic-auth-file=<csv 파일 경로>
    >     ```
    >     
    >     - kube-apiserver 서비스 또는 파드 정의 파일에 **`—basic-auth-file=<csv 파일 경로>`** 옵션을 추가한다.
    >     - kubeadm으로 설치한 경우 kube-apiserver 파드 정의 파일을 수정해야한다.
    >     - 변경 사항 적용을 위해 api서버를 재시작한다.(kubeadm은 자동 재시작)
    > 
    > ![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%204.png)
    > 
    > 1. **API 서버 접근 시 인증**
    >     
    >     ```bash
    >     curl -u <사용자이름>:<비밀번호> <API 서버 주소>
    >     ```
    >     
    >     - 해당 명령어를 사용하여 API 서버에 접근한다
- **2. 정적 토큰 파일 기반 인증 방식**
    
    > 
    > 
    > 
    > ![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%205.png)
    > 
    > 1. **토큰 정보 파일 생성**
    >     - 비밀번호 대신 토큰을 사용하여 사용자 정보를 저장
    >     - 파일 형식은 비밀번호 파일과 동일함.
    > 2. **API 서버 설정**
    >     - kube-apiserver 서비스 또는 파드 정의 파일에 —token-auth-file<토큰파일경로> 옵션을 추가한다.
    > 3. **API 서버 접근 시 인증**
    >     
    >     ```bash
    >     curl -H “Authorization: Bearer <토큰>” <API 서버 주소>
    >     ```
    >     
    >     - curl -H “Authorization: Bearer <토큰>” <API 서버 주소> 명령어를 사용하여 API 서버에 접근한다.
- **3. 인증서 기반 인증 방식**
    
    > 
    > 
    > 
    > 
- **4. LDAP, Kerveros 등 외부 인증 프로토콜 인증 방식**
    
    

### 📌 1. 정적 비밀번호 파일 방식

- `/etc/kubernetes/basic-auth.csv` 등 파일에 사용자 정보를 저장

```bash
비밀번호, 사용자이름, 사용자ID, 그룹
123456, admin, 1, system:masters
```

- `kube-apiserver` 실행 시 다음 옵션 추가

```bash
--basic-auth-file=/etc/kubernetes/basic-auth.csv
```

- 접근 시 예시

```bash
curl -u admin:123456 https://<api-server>
```

🔸 보안상 실서비스에는 부적합, 테스트/교육용으로만 사용을 권장함.

---

### 📌 2. 정적 토큰 기반 인증 방식

- CSV 파일 형식:

```bash
<token>, <username>, <userid>, <group>
abc123token, devuser, 1001, dev-team
```

- `kube-apiserver` 실행 시 옵션 추가:

```bash
--token-auth-file=/etc/kubernetes/token.cs
```

- 접근 예시:

```bash
curl -H "Authorization: Bearer abc123token" https://<api-server>
```

🔸 토큰 유출 시 보안 위협 → 서비스용에는 권장되지 않음

---

### 📌 3. 인증서 기반 인증 방식 (추천)

- 사용자를 위한 인증서(Private key + Signed Cert)를 발급하고, API 서버는 CA를 통해 검증
- kubeconfig 파일에 사용자 인증서 포함

✅ 보안이 뛰어나며, 실무에서 가장 일반적으로 사용됨

---

### 📌 4. LDAP / OIDC / Kerberos 등 외부 인증 연동

- 기존 인증 시스템(사내 LDAP, 구글 OIDC 등)과 연동 가능
- 기업 환경에서 사용자 관리 일원화 가능

---

### 📌 5. 서비스 계정 (ServiceAccount)

- 파드나 컨테이너가 API에 접근할 수 있게 해주는 수 계정
- 자동으로 생성되며, 토큰은 파드 내부에 mount됨

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: myapp
```

- 접근 시:

```bash
curl -H "Authorization: Bearer $(cat /var/run/secrets/kubernetes.io/serviceaccount/token)" ...
```

## 🧾 권한 부여(Authorization) 방식

> 인증된 사용자에 대해, 어떤 작업을 어느 리소스에 할 수 있는지 결정
> 

### ✅ 주요 권한 부여 방식

| 방식 | 특징 | 설명 |
| --- | --- | --- |
| **RBAC (가장 일반적)** | ✅ 권장 | 사용자에게 역할(Role)을 부여 |
| ABAC | 🔸 과거 방식 | 사용자 속성 기반 규칙 |
| Node Authorizer | 내부 노드만 접근 허용 | kubelet, node 등 시스템 접근 제어 |
| Webhook Authorizer | 외부 서비스와 연동 | 외부 시스템에 질의하여 권한 결정 |

---

## 5. 🔒 TLS 통신 보안

### ✔️ 클러스터 내부 구성요소 간 통신은 모두 TLS로 보호됨

![img1.daumcdn.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/img1.daumcdn%206.png)

- 인증서와 키는 주로 `/etc/kubernetes/pki`에 위치
- 대상 예:
    - etcd ↔ kube-apiserver
    - kubelet ↔ kube-apiserver
    - kubectl ↔ API 서버

```bash
kubectl config view
# 내부에 client-certificate, client-key 경로가 존재
```

---

## 6. 🔗 네트워크 보안 정책 (NetworkPolicy)

- 기본적으로 모든 파드는 서로 자유롭게 통신 가능
- 그러나 보안을 위해 **파드 간 통신을 제어해야 함**

### 예시: 특정 파드만 db에 접근 허용

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-db
spec:
  podSelector:
    matchLabels:
      app: db
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: backend
```

✅ Calico, Cilium, Weave 등 CNI 플러그인 설치가 필요

## 7. 사용자 유형 및 관리 전략

### 사용자 관리 방식

> 쿠버네티스는 자체적으로 사용자 계정을 관리하지 않는다.
> 

<aside>
💡

외부소스(파일, 인증서, LDAP 등)을 통해 사용자를 관리한다.

따라서 **`kubectl 명령어`**로 **생성하거나 목록을 확인할 수 없다**.

단, 서비스 계정은 쿠버네티스 API를 통해 생성 및 관리할 수 있다.

</aside>

| 유형 | 설명 |
| --- | --- |
| **관리자** | 클러스터 설정/운영 권한 보유 |
| **개발자** | 네임스페이스 단위로 앱 배포 및 테스트 |
| **최종 사용자** | 클러스터에 배포된 서비스 사용 |
| **외부 시스템/앱** | 통합 목적 API 접근 (예: CI/CD 시스템) |

| 구분 | 설명 | 인증 방식 |
| --- | --- | --- |
| 사람 (관리자, 개발자) | CLI, Dashboard, IDE 접근 | 인증서, 외부 인증, token |
| 로봇 (앱, 파드 등) | 자동화된 접근 | ServiceAccount 기반 토큰 |

## 8. 문제 풀기전 개념 정리

## 🔷 1. **Kube API Server란?**

### ✅ 역할:

- 쿠버네티스 클러스터의 **중앙 통신 허브**.
- `kubectl` 명령어나 다른 컴포넌트(컨트롤러, 스케줄러 등)의 요청을 받아서 처리함.
- 클러스터 자원(CPU, Pod, Deployment 등)에 대한 **읽기/쓰기 작업의 출입구** 역할.

### ✅ 예시:

- `kubectl get pods` → kube-apiserver가 etcd에서 정보를 읽어 옴.
- `kubectl apply -f deployment.yaml` → kube-apiserver가 클러스터에 새로운 리소스를 생성.

---

## 🔷 2. **etcd 서버란?**

### ✅ 역할:

- 쿠버네티스의 **영구 데이터 저장소 (Key-Value 스토어)**.
- 클러스터의 상태 정보(Pod, ConfigMap, Secret, 노드 정보 등)를 저장함.
- kube-apiserver는 etcd에 데이터 저장/조회.

### ✅ 예시:

- kube-apiserver가 etcd에 “이런 Pod이 존재해요”라고 기록.
- 클러스터 재시작 후에도 상태가 유지되는 이유가 바로 etcd 덕분.

---

## 🔒 3. **각 서버의 인증서란?**

### 📌 Kube API Server 인증서

| 항목 | 설명 |
| --- | --- |
| **사용 목적** | 사용자가 API 서버에 HTTPS로 접속할 때 자신이 "진짜 kube-apiserver"임을 증명 |
| **경로 예시** | `/etc/kubernetes/pki/apiserver.crt`, `/etc/kubernetes/pki/apiserver.key` |
| **기능** | TLS 암호화 통신 제공 + 서버 신뢰성 검증 |
| **사용처** | `kubectl`, 다른 컨트롤러가 API 서버에 접근 시 사용됨 |

### 📌 ETCD 서버 인증서

| 항목 | 설명 |
| --- | --- |
| **사용 목적** | etcd 서버가 "나는 진짜 etcd 서버입니다"라고 API 서버에 증명 |
| **경로 예시** | `/etc/kubernetes/pki/etcd/server.crt`, `/etc/kubernetes/pki/etcd/server.key` |
| **기능** | API 서버가 etcd에 HTTPS 요청 시 인증서로 서버 신원 확인 |
| **사용처** | kube-apiserver가 etcd와 안전하게 통신할 때 사용됨 |

---

## 🔐 1. TLS 통신이란?

### 현실 비유:

> 우리가 어떤 정부기관이나 은행 같은 신뢰할 수 있는 상대와 통신하려면, "신분증"과 "공식 도장"이 있어야 믿죠?
> 

TLS 통신도 똑같습니다.

- 상대방이 **진짜 맞는지(신분 확인)**,
- **중간에서 누가 엿듣거나 가로채지 못하도록 암호화된 채널**을 만드는 게 목적이에요.

TLS는 다음 3단계로 작동해요:

- 참고
    
    ## 🔐 서로 신뢰하는 방식 (TLS 개념)
    
    1. **etcd 서버는** `server.crt`를 사용해서 자신을 인증.
    2. **kube-apiserver는** etcd가 **신뢰할 수 있는 CA가 서명한 인증서인지** 확인하기 위해 CA 인증서(`ca.crt`)를 가지고 있음.
    3. 반대로, **etcd도 클라이언트(예: kube-apiserver)의 인증서**가 CA에서 발급됐는지 확인함.

| 단계 | 설명 |
| --- | --- |
| 1. 인증서 확인 | "당신이 진짜 kube-apiserver 맞습니까?" 인증서로 신원을 확인 |
| 2. 인증서 유효성 검사 | 인증서가 **믿을 수 있는 CA**에 의해 서명되었는지 확인 |
| 3. 비밀키 기반 암호화 채널 설정 | 대칭키를 만들어 양방향 암호화 통신 시작 |

---

## 📜 2. CA(Certificate Authority)란?

> 현실에선 ‘정부’가 여권을 발급하듯이, 디지털 세계에선 ‘CA’가 인증서를 발급합니다.
> 
- CA는 **신뢰할 수 있는 제3자**예요.
- 인증서를 발급하면서 “이 공개키는 이 주체(예: kube-apiserver)의 것입니다”라는 도장을 찍어줍니다.

### 예시:

| 발급 주체 | 실제 인증서 예 |
| --- | --- |
| Let's Encrypt | 웹사이트 인증서 |
| Kubernetes 클러스터 내부 CA | `/etc/kubernetes/pki/ca.crt` |

---

## 📛 3. CN(Common Name)이란?

> 인증서에 적힌 “이건 누구의 것이다”를 나타내는 이름표입니다.
> 

예:

- CN = `kube-apiserver`
- CN = `etcd`
- 또는 CN = `system:node:worker-1`

CN은 서버 이름이거나, 사용자/노드의 ID 역할을 해요.

🔐 TLS 통신 중 **서버 이름(CN)** 과 **클라이언트가 접속하려는 대상 이름**이 일치해야 합니다.

---

## 🧩 4. Kubernetes 구성요소 사이 통신 관계

Kubernetes는 많은 구성요소가 서로 **TLS 통신**으로 보안 연결을 맺어요. 여기서 각각의 역할과 인증서/CA 관계를 설명할게요.

### 🔄 kube-apiserver ↔ etcd

| 항목 | 설명 |
| --- | --- |
| 누구? | kube-apiserver가 etcd에 접근해서 클러스터 상태를 저장/조회 |
| 어떻게? | TLS 사용 |
| 인증서 역할 | etcd는 **서버 인증서**, kube-apiserver는 **클라이언트 인증서** |
| CA 역할 | etcd는 자신의 인증서가 어떤 CA로부터 발급되었는지 클라이언트에게 증명 |

### 예시 흐름:

1. kube-apiserver가 etcd에 연결
2. etcd가 서버 인증서 전송 (CN=etcd)
3. kube-apiserver는 그 인증서가 자신이 신뢰하는 CA(`etcd-ca.crt`)로 서명되었는지 확인
4. 신뢰되지 않으면 → ❌ `x509: certificate signed by unknown authority` 에러 발생

---

### 🔄 kubectl ↔ kube-apiserver

| 항목 | 설명 |
| --- | --- |
| 누구? | 유저가 `kubectl` 명령어로 kube-apiserver에 명령 전달 |
| 인증 방식 | 클라이언트 인증서 (보통 kubeconfig에 포함됨) |
| CA 역할 | kube-apiserver는 클라이언트 인증서를 검증하기 위해 `ca.crt` 보관 중 |

---

## 📉 인증 실패 사례 vs. 원인 요약

| 에러 메시지 | 원인 | 비유 |
| --- | --- | --- |
| `x509: certificate signed by unknown authority` | 인증서의 CA가 신뢰되지 않음 | 누가 줬는지 모르는 신분증이라 인정 못함 |
| `x509: certificate is valid for X, not Y` | CN(SAN)이 접속 대상과 불일치 | 홍길동 신분증인데 김철수에게 제시함 |
| `tls: bad certificate` | 인증서 자체가 만료됐거나 위조됨 | 유효기간 지난 여권 |

---

## 🛠️ 실전에서 확인할 것들

| 체크포인트 | 명령어 예시 |
| --- | --- |
| 인증서에 어떤 CN, SAN이 있는지 | `openssl x509 -in server.crt -text -noout` |
| 인증서 발급자(CA)가 누구인지 | `Issuer:` 항목 확인 |
| 클라이언트가 어떤 CA를 신뢰하고 있는지 | 예: `/etc/kubernetes/pki/ca.crt`, `/etc/ssl/certs/ca-bundle.crt` |

| 구성 요소 | 의미 |
| --- | --- |
| `openssl` | OpenSSL 툴 실행 |
| `x509` | X.509 형식의 인증서 처리 모드 (표준 인증서 형식) |
| `-in server.crt` | 분석할 입력 파일로 `server.crt`를 지정 |
| `-text` | 인증서를 사람이 읽을 수 있는 형식(텍스트)으로 출력 |
| `-noout` | 인증서 자체의 PEM 인코딩(-----BEGIN CERTIFICATE----- ~ -----END-----)은 출력하지 않음 |

---

## ✅ 요약

- **TLS**는 서로 신뢰를 검증하고 암호화 통신을 보장하는 프로토콜
- **CA**는 "이 인증서 진짜 맞아"라고 보증해주는 기관
- **CN/SAN**은 인증서의 주인 이름표
- **Kubernetes 구성요소들은 모두 TLS로 통신하며**, **올바른 인증서, CN, CA가 없으면 연결 실패**

---

## **9. Practice Test - View Certificates**

<aside>
💡

**1. Identify the certificate file used for the kube-api server.**

- 번역
    
    kube-api 서버에서 사용하는 인증서 파일을 식별하시오.
    
</aside>

- **힌트 1. 로컬 노드의 `kube-apiserver static pod` 정의 파일을 직접 읽어 TLS 관련 설정을 확인하는 명령어**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image.png)
    > 
    > ```bash
    > cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep tls
    > ```
    > 
    > - kube-apiserver가 **어떤 인증서 파일을 참조하는지 직접 확인**할 수 있음.
    > - 예를 들면 `-tls-cert-file`, `-tls-private-key-file`, `-etcd-certfile`, `-client-ca-file` 같은 설정 확인 가능.
    > 
    > > → kube-apiserver가 TLS 서버로 동작할 때 사용하는 인증서 파일을 찾으라는 뜻입니다.
    > > 
    > 
    > ---
    > 
    > ## 📁 주어진 설정에서 확인된 인증서 관련 항목들:
    > 
    > ```bash
    > - --tls-cert-file=/etc/kubernetes/pki/apiserver.crt         ✅
    > - --tls-private-key-file=/etc/kubernetes/pki/apiserver.key
    > - --client-ca-file=/etc/kubernetes/pki/ca.crt
    > - --etcd-cafile=/etc/kubernetes/pki/etcd/ca.crt
    > - --etcd-certfile=/etc/kubernetes/pki/apiserver-etcd-client.crt
    > - --kubelet-client-certificate=/etc/kubernetes/pki/apiserver-kubelet-client.crt
    > - --proxy-client-cert-file=/etc/kubernetes/pki/front-proxy-client.crt
    > - --requestheader-client-ca-file=/etc/kubernetes/pki/front-proxy-ca.c
    > ```
    > 
    > ---
    > 
    > ## ✅ 어떤 인증서를 "서버 인증서"로 보는가?
    > 
    > ### 핵심 옵션:
    > 
    > ```
    > --tls-cert-file=/etc/kubernetes/pki/apiserver.crt
    > ```
    > 
    > 이 옵션이 의미하는 바는 다음과 같습니다:
    > 
    > - `kube-apiserver`가 **서버 역할**로 통신할 때,
    > - 클라이언트 (예: kubectl, kubelet 등)에게 자신을 증명하기 위해
    > - **이 인증서(`apiserver.crt`)를 사용**한다는 뜻입니다.
    > 
    > 즉,
    > 
    > > kube-apiserver가 TLS 서버로 동작할 때 사용하는 인증서는 바로
    > > 
    > > - `*/etc/kubernetes/pki/apiserver.crt**`입니다.
    > 
    > ---
    > 
    > ## 🧠 왜 다른 인증서가 아닌 이 파일인가?
    > 
    > | 인증서 경로 | 용도 | 이유 |
    > | --- | --- | --- |
    > | `/etc/kubernetes/pki/apiserver.crt` | **API 서버의 TLS 인증서** | `--tls-cert-file`은 서버가 HTTPS로 클라이언트 요청 받을 때 사용 |
    > | `/etc/kubernetes/pki/apiserver-etcd-client.crt` | etcd에 접근할 때 클라이언트 인증서 | API 서버 → etcd |
    > | `/etc/kubernetes/pki/apiserver-kubelet-client.crt` | kubelet에 접근할 때 클라이언트 인증서 | API 서버 → kubelet |
    > | `/etc/kubernetes/pki/front-proxy-client.crt` | aggregator용 인증서 | 요청 프록시 처리용 |
    > | `/etc/kubernetes/pki/ca.crt` | 클라이언트 인증서 검증용 CA | 클라이언트 → API 서버 시 검증 |
    > | `/etc/kubernetes/pki/front-proxy-ca.crt` | 요청 헤더 프록시 인증용 CA | API 서버 → aggregator |
- **힌트 2. 클러스터 내부의 `kube-apiserver-controlplane` 파드에 대한 kubectl describe 정보에서 `tls`가 포함된 줄을 찾는 명령어**
    
    > 
    > 
    > 
    > ```bash
    > kubectl -n kube-system describe pods kube-apiserver-controlplane | grep tls
    > ```
    > 
    > - 이 명령은 **API 서버 파드가 클러스터 내에서 어떤 식으로 실행되고 있는지**를 관찰할 수는 있지만, 실제 파일 경로나 TLS 경로는 **출력되지 않을 수도 있음**.
    
    ### ⚠️ 주의:
    
    - `describe pods`는 파드 상태, 이벤트, 볼륨 마운트, 이미지 등 다양한 메타정보를 보여주지만,
        
        kube-apiserver가 사용 중인 인증서 경로 같은 **실제 실행 인자 (`--tls-cert-file` 등)**는 보통 나타나지 않습니다.
        
    

---

<aside>
💡

**2. Identify the Certificate file used to authenticate kube-apiserver as a client to ETCD Server.**

- 번역
    
    kube-apiserver가 ETCD 서버에 클라이언트로 인증할 때 사용하는 인증서 파일을 식별하시오.
    
</aside>

- **힌트 1. 로컬 노드의 `kube-apiserver static pod` 정의 파일을 직접 읽어 TLS 관련 설정을 확인하는 명령어**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%201.png)
    > 
    > ```bash
    > cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep etcd
    > ```
    > 

---

<aside>
💡

1. **Identify the key used to authenticate kubeapi-server to the kubelet server**
- 번역
    
    kubeapi-server가 kubelet 서버에 인증할 때 사용하는 키를 식별하시오.
    
</aside>

- **힌트 1. 로컬 노드의 `kube-apiserver static pod` 정의 파일을 직접 읽어 TLS 관련 설정을 확인하는 명령어**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%202.png)
    > 
    > ```bash
    > cat /etc/kubernetes/manifests/kube-apiserver.yaml | grep kubelet
    > ```
    > 

---

<aside>
💡

1. **Identify the ETCD Server Certificate used to host ETCD server.**
- 번역
    
    **ETCD 서버를 호스팅할 때 사용되는 ETCD 서버 인증서를 식별하시오.**
    
</aside>

- **힌트 1. Kubernetes 클러스터의 etcd 서버를 static pod로 실행할 때 사용하는 Pod 정의 파일**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%203.png)
    > 
    > ```bash
    > cat /etc/kubernetes/manifests/etcd.yaml | grep cert
    > ```
    > 

---

<aside>
💡

1. **Identify the ETCD Server CA Root Certificate used to serve ETCD Server.**

**ETCD can have its own CA. So this may be a different CA certificate than the one used by kube-api server**.

- 번역
    
    ETCD 서버를 서비스할 때 사용하는 CA 루트 인증서를 식별하시오
    
    ETCD는 자체 CA를 가질 수 있으므로, 이 인증서는 kube-api 서버에서 사용하는 CA 인증서와 다를 수 있습니다.
    
</aside>

- **힌트 1. Kubernetes 클러스터의 etcd 서버를 static pod로 실행할 때 사용하는 Pod 정의 파일**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%204.png)
    > 
    > ```bash
    > cat /etc/kubernetes/manifests/etcd.yaml | grep ca
    > ```
    > 

---

<aside>
💡

1. What is the Common Name (CN) configured on the Kube API Server Certificate?

**OpenSSL Syntax:** `openssl x509 -in file-path.crt -text -noout`

- 번역
    
    Kube API 서버 인증서에 설정된 Common Name(CN)은 무엇인가요?
    OpenSSL 명령어 형식: `openssl x509 -in 파일경로.crt -text -noout`
    
</aside>

- **힌트 1. TLS 인증서 정보 확인**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%205.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/apiserver.crt -text
    > ```
    > 

---

<aside>
💡

1. What is the name of the CA who issued the Kube API Server Certificate?
- 번역
    
    Kube API 서버 인증서를 발급한 CA의 이름은 무엇인가요?
    
</aside>

- **힌트 1. TLS 인증서 정보 확인**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%205.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/apiserver.crt -text
    > ```
    > 

---

<aside>
💡

8.  Which of the below alternate names is not configured on the Kube API Server Certificate?

- 번역
    
    다음 중 Kube API 서버 인증서에 설정되지 않은 대체 이름(Alternate Name)은 무엇인가요?
    
</aside>

- **힌트 1. TLS 인증서 정보 확인**
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%206.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/apiserver.crt -text -noout | grep -A1 "Subject Alternative Name"
    > ```
    > 
    > 이 인증서에는 총 **7개의 SAN(Subject Alternative Names)** 이 설정되어 있습니다:
    > 
    > ### 📌 DNS 이름:
    > 
    > 1. controlplane
    > 2. kubernetes
    > 3. kubernetes.default
    > 4. kubernetes.default.svc
    > 5. kubernetes.default.svc.cluster.local
    > 
    > ### 📌 IP 주소:
    > 
    > 1. 172.20.0.1
    > 2. 192.168.193.133
    > 
    > ---
    > 
    > ## ✅ 정답을 찾는 방법
    > 
    > 문제에서 보기를 주었을 텐데, 보기 목록 중 **위 리스트에 없는 값**이 정답
    > 

---

<aside>
💡

1. What is the Common Name (CN) configured on the ETCD Server certificate?
- 번역
    
    **etcd server 인증서에 구성된 CN은 무엇인가요?**
    
</aside>

- 힌트 1.
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%207.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/etcd/server.crt -text | grep CN
    > ```
    > 

---

<aside>
💡

1. How long, from the issued date, is the Kube-API Server Certificate valid for?
- 번역
    
    **etcd server ca인증서는 발급일로부터 얼마 동안 유효하나요?**
    
</aside>

- 힌트 1.
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%208.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/apiserver.crt -noout -dates
    > ```
    > 

---

<aside>
💡

1. How long, from the issued date, is the Root CA Certificate valid for?
- 번역
    
    **etcd server ca인증서는 발급일로부터 얼마 동안 유효하나요?**
    
</aside>

- 힌트 1.
    
    > 
    > 
    > 
    > ![image.png](ch%207_security_%E1%84%8B%E1%85%B5%E1%86%AB%E1%84%8C%E1%85%B3%E1%86%BC%20%E1%84%86%E1%85%B5%E1%86%BE%20TLS(1%204)%20215cda69b14380cd8c93f7c40470f6ae/image%209.png)
    > 
    > ```bash
    > openssl x509 -in /etc/kubernetes/pki/ca.crt -text
    > ```
    > 

---

<aside>
💡

1. Kubectl suddenly stops responding to your commands. Check it out! Someone recently modified the `/etc/kubernetes/manifests/etcd.yaml` file
    
    You are asked to investigate and fix the issue. Once you fix the issue wait for sometime for kubectl to respond. Check the logs of the ETCD container.
    
- 번역
    
    **Kubectl이 갑자기 명령어에 반응하지 않습니다. 확인해보세요! 누군가 최근에 `/etc/kubernetes/manifests/etcd.yaml` 파일을 수정했습니다.**
    
    문제를 조사하고 수정하라는 요청을 받았습니다. 문제를 해결한 후 잠시 기다렸다가 kubectl이 정상적으로 반응하는지 확인하세요. 그리고 ETCD 컨테이너의 로그를 확인하세요.
    
</aside>

- 힌트 1.
    
    > 
    > 
    > 
    > ### 문제 상황 설명
    > 
    > - `kubectl`이 명령어에 반응하지 않는다는 것은 Kubernetes API 서버와의 통신에 문제가 있다는 뜻일 가능성이 큽니다.
    > - `/etc/kubernetes/manifests/etcd.yaml`은 클러스터 내 etcd(분산 키-값 저장소)를 static pod로 실행하는 데 사용하는 설정 파일입니다.
    > - etcd는 쿠버네티스 클러스터 상태 저장소로 매우 중요하기 때문에 etcd가 제대로 동작하지 않으면 API 서버가 정상 동작하지 못해 kubectl 명령이 응답하지 않을 수 있습니다.
    > - 따라서 최근에 etcd pod 설정파일(`/etc/kubernetes/manifests/etcd.yaml`)을 누군가 수정한 것이 원인일 가능성이 큽니다.
    > 
    > ---
    > 
    > ### 문제 해결 절차 및 예상 답변
    > 
    > 1. **etcd.yaml 파일 문법 및 설정 오류 확인**
    >     
    >     ```bash
    >     sudo cat /etc/kubernetes/manifests/etcd.yaml
    >     ```
    >     
    >     - 최근 수정된 내용을 확인하세요.
    >     - 오타, 들여쓰기, 잘못된 경로나 인증서 경로, 포트 번호, 환경 변수 설정 등을 체크합니다.
    > 2. **etcd static pod 상태 확인**
    >     
    >     ```bash
    >     sudo crictl pods | grep etcd
    >     ```
    >     
    >     또는
    >     
    >     ```bash
    >     kubectl get pods -n kube-system | grep etcd
    >     ```
    >     
    >     (kubectl이 안 될 때는 노드에서 직접 컨테이너 상태 확인 필요)
    >     
    > 3. **etcd pod 로그 확인**
    >     
    >     ```bash
    >     sudo crictl logs <etcd-pod-id>
    >     ```
    >     
    >     또는 kubelet이 로그를 관리하는 위치에서 확인 가능
    >     
    >     ```bash
    >     journalctl -u kubelet -f
    >     ```
    >     
    >     혹은
    >     
    >     ```bash
    >     docker logs <etcd-container-id>
    >     ```
    >     
    >     - 로그에서 오류 메시지를 찾습니다. 인증서 관련 오류, 포트 충돌, 파일 경로 문제 등이 흔함.
    > 4. **수정 예시**
    >     - 인증서 파일 경로가 잘못 지정된 경우, 올바른 경로로 수정.
    >     - YAML 문법 오류(들여쓰기, 콜론 등)를 바로잡기.
    >     - 포트 충돌 시 포트 번호 변경 또는 중복 프로세스 종료.
    > 5. **etcd pod가 다시 정상 실행되는지 기다리기**
    >     - static pod는 kubelet이 파일을 감하며 변경 시 자동으로 재시작합니다.
    >     - 재시작 후 정상 상태(`Running`)인지 확인.
    > 6. **kubectl 명령어 테스트**
    >     
    >     ```bash
    >     kubectl get nodes
    >     ```
    >     
    >     - 반응이 정상적으로 돌아오면 문제 해결 완료.
    > 
    > ---
    > 
    > ### 요약
    > 
    > - `/etc/kubernetes/manifests/etcd.yaml` 파일 수정으로 etcd pod가 실패하거나 중지됐을 가능성이 큽니다.
    > - 해당 파일 설정 오류를 찾아 수정하세요.
    > - 수정 후 kubelet이 pod를 재시작하므로 잠시 기다립니다.
    > - `kubectl`이 다시 반응하면 정상 복구된 것입니다
    > - etcd 컨테이너 로그는 문제 원인을 찾는 데 가장 중요하니 꼭 확인하세요.
    > 

---