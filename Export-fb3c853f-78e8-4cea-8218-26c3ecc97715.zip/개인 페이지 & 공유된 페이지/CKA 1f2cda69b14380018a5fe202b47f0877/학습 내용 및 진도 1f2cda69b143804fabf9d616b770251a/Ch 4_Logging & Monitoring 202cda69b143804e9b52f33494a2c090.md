# Ch 4_Logging & Monitoring

사람: 김형민
완료 여부: Yes
작성일: 2025년 6월 9일
주차: 2주차, 3주차

# **Logging and Monitoring Section Introduction**

1. 클러스터 구성 요소 모니터링 방법
    1. 모니터링 연습문제
2. 애플리케이션 로그 확인 및 관리 방법
    1. 애플리케이션 로그 모니터링 연습문제

## 1. 클러스터 구성 요소 모니터링 방법

쿠버네티스!!!! 에서는 모니터링을 어떻게 하는지 궁금함.

일단 그 전에 node, 컨테이너, pod, kubelet의 개념을 다시 정리함.

1. **node** : kubrernetes 클러스터를 구성하는 실제!!!! 또는 가상 머신임 (물리서버, EC2 인스턴스 등)
2. **pod** : 하나 이상의 컨테이너가 실행 되는 작은 배포 단위 (Nginx 컨테이너 + log sidecar 컨테이너)
3. **Container** : 실제 실행되는 애플리케이션 환경(기본적로 Docker 컨테이너 개념과 비슷함)

```jsx
Kubernetes Cluster
│
├─ Node A (노드)
│   ├─ Pod 1
│   │   ├─ Container(docker) A
│   │   └─ Container(docker) B
│   └─ Pod 2
│       └─ Container(docker) C
│
└─ Node B (노드)
    └─ Pod 3
        └─ Container(docker) D

```

💡 **중요한 포인트**

- 하나의 **Pod**는 반드시 하나의 **Node**에만 속할 수 있다
- 하나의 **Pod** 안에는 여러 개의 **Container**가 있을 수 있다
- **Node**는 여러 개의 **Pod**를 수용할 수 있다
- 컨테이너는 반드시 **Pod** 안에 있어야 하며, Pod 없이 단독 실행되지 않는다 (Kubernetes 상에서는)

### 1.1 그러면 도대체 어떻게 각 Pod의 Container들의 리소스를 보고받니?

![image.png](Ch%204_Logging%20&%20Monitoring%20202cda69b143804e9b52f33494a2c090/image.png)

구성도는 이렇게 된다. 

쿠버네티스에서는 자체? 적으로 제공하는 경량 모니터링 서비스 Metrics server 가 있고, prometheus, elastic stack 등을 많이 사용한다.

단, Metrics server는 디스크에 저장하지 않고 내부 캐시저장소(메모리)에 저장한다. 

서버 닫으면 날라감

1. metrics server 실행

```jsx
minikube addons enable metrics-server
```

1. cpu 및 memory 사용량 확인

```jsx
kubectl top node
```

1. 파드의 성능 지표를 확인

```jsx
kubectl top pod
```

### 1.a 모니터링 연습문제

1. We have deployed a few PODs running workloads. Inspect them.
    
    Wait for the pods to be ready before proceeding to the next question.
    

```
kubectl get pods
```

1. Let us deploy the Metrics Server to enable monitoring of the PODs and Nodes in the cluster.
    - 번역
        
        클러스터에서 파드(POD)와 노드(NODE)를 모니터링할 수 있도록 Metrics Server를 배포합시다.
        
    
    ```
    배포 하자니까 걍 OK
    ```
    
2. Deploy the Metrics Server in your Kubernetes cluster by applying the latest release `components.yaml` manifest using the following command:
    
    Run the `kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml`
    
    - 번역
        
        다음 명령어를 사용하여 최신 릴리스의 `components.yaml` 매니페스트를 적용함으로써 Kubernetes 클러스터에 Metrics Server를 배포하세요: 
        
        `kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml`
        
    
    ```
    kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
    ```
    
3. It takes a few minutes for the metrics server to start gathering data.
    
    Run the `kubectl top node` command and wait for a valid output.
    
    - 번역
        
        Metrics Server가 데이터를 수집하기 시작하는 데에는 몇 분 정도 걸립니다.
        
        `kubectl top node` 명령어를 실행하고 유효한 출력이 나올 때까지 기다리세요.
        
    
    ```
    kubectl top node
    ```
    
4. Identify the node that consumes the `most` CPU(cores).
5. Identify the node that consumes the `most` Memory(bytes).
6. Identify the POD that consumes the `most` Memory(bytes) in default namespace.

```
kubectl top pods
```

1. Identify the POD that consumes the `least` CPU(cores) in default namespace.

## 로깅

### 로깅 연습문제

1. We have deployed a POD hosting an application. Inspect it. Wait for it to start.
- 번역
    
    애플리케이션을 호스팅하는 파드를 배포했습니다. 이를 확인하고, 시작될 때까지 기다리세요.
    

```
kubectl get pod
```

1. A user - `USER5` - has expressed concerns accessing the application. Identify the cause of the issue.
    
    Inspect the logs of the POD
    
- 번역
    
    사용자 USER5가 애플리케이션에 접근하는 데 문제가 있다고 보고했습니다. 문제의 원인을 확인하세요.
    
    파드의 로그를 확인해보세요.
    

```
kubectl logs webapp-1(-k)옵션은 실시간옵션
```

- 답
    
    ![image.png](Ch%204_Logging%20&%20Monitoring%20202cda69b143804e9b52f33494a2c090/image%201.png)
    
1. We have deployed a new POD - `webapp-2` - hosting an application. Inspect it. Wait for it to start.
- 번역
    
    
    새로운 파드 `webapp-2`를 배포하여 애플리케이션을 호스팅했습니다. 이를 확인하고, 시작될 때까지 기다리세요.
    

```
kubectl get pods
```

1. A user is reporting issues while trying to purchase an item. Identify the user and the cause of the issue.
    
    Inspect the logs of the webapp in the POD
    
- 번역
    
    사용자가 상품 구매 시 문제를 보고하고 있습니다. 해당 사용자를 확인하고 문제 원인을 파악하세요.
    
    파드에 있는 webapp의 로그를 확인하세요.
    

```
kubectl logs webapp-2
```

### 1. **`-tail` 옵션**

최근 로그 몇 줄만 출력합니다. 예를 들어, 최근 100줄만 보고 싶다면

```bash
kubectl logs webapp-2 --tail=100
```

---

### 2. **`f` 옵션과 함께 사용**

실시간 로그를 보면서 특정 키워드를 찾고 싶을 때:

```bash
kubectl logs -f webapp-2 | grep "ERROR"
```

`grep`으로 원하는 단어만 필터링해서 실시간으로 볼수 있다.

---

### 3. **파이프(|)와 `less` 사용하기**

스크롤 하면서 로그를 탐색할 수 있습니다:

```bash
kubectl logs webapp-2 | les
```

`less` 안에서는 스페이스바로 페이지 내려가고, `q`로 나올 수 있어요.

---

### 4. **`-since` 옵션**

최근 특정 시간 이후 로그만 보고 싶을 때, 예를 들어 최근 10분 로그:

```bash
kubectl logs webapp-2 --since=10m
```