# Ch 5_Application Lifecycle Management

사람: Jeon Jeon
완료 여부: No
주차: 2주차