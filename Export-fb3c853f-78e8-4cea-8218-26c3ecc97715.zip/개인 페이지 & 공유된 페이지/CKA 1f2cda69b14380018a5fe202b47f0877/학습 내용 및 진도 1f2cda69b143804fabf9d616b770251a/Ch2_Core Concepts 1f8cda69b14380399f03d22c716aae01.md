# Ch2_Core Concepts

사람: Dahui Kim
완료 여부: Yes
작성일: 2025년 5월 25일
주차: 1주차

## Core Concept

> 쿠버네티스의 목적 : 애플리케이션을 컨테이너 형태로 호스팅하는 과정을 자동화하는 것
> 
- 장점
    - 요구에 따라 애플리케이션의 많은 인스턴스를 쉽게 배포 가능
    - 애플리케이션 내 다양한 서비스 간 통신 지원

### Cluster Architecture

- k8s는 크게 Master node와 worker node로 구성되어있으며 각 노드는 특정 역할을 수행하는 다양한 컴포넌트들로 구성되어있음
    - master node(제어 노드) : 클러스터의 상태 관리, 작업 스케줄링, 동작 제어의 역하 수행
        - etcd : key-value 형식으로 클러스터의 모든 설정과 상태 정보를 저장하는 분산 데이터베이스
            - 복수의 노드(etcd 인스턴스)와 통신하며 합의를 이루는 구조 → 하나의 노드가 다운되더라도 과반수 이상 노드가 살아 있으면 클러스터가 정상 동작
                - 리더 노드가 write 요청 처리, 다른 노드들은 복제를 통해 데이터 동기화(투표를 통해 리더 선출)
        - kube-scheduler : 새로운 Pod을 적절한 작업 노드에 할당(pod 스케줄링)
        - controller-manager : 다양한 컨트롤러를 통합 관리
            - node-controller : 노드 상태 감시 및 관리
            - replication-controller : 정의된 수만큼의 Pod 복제본을 유지
        - kube-apiserver : 클러스터 내 모든 컴포넌트와의 통신 중심점
            - 모든 요청은 API 서버를 통해 이루어짐
            - 클러스터의 상태를 중앙에서 관리
    - worker node(작업 노드) : 컨테이너의 형식의 응용 프로그램을 호스트
        - Kubelet : 각 노드에 존재
            - 컨테이너 상태 모니터링
            - kube-apiserver와 통신하여 명령을 수행
        - kube-proxy : 클러스터 내 서비스 간 통신 지원
            - 네트워크 프록시 역할
    - 컨테이너 런타임 엔진 : 컨테이너를 실제로 실행하는 소프트웨어(e.g. docker, containerD, rocket)
        - 클러스터 내 모든 노드에 설치되어있어야함

### ETCD

신뢰할 수 있는 분산 key-value 데이터 베이스

- 문서 또는 페이지 형태로 정보를 저장
- Key-Value Store : NoSQL의 하위 분류
    - 가장 단순한 형태의 NoSQL
- 분산 환경에서 설정값과 상태 정보를 저장(yaml, json 파일 등)
- Raft Consensus 알고리즘을 내장해 클러스터 내 모든 Etcd 인스턴스간 consensus(합의)를 통해 데이터 저장
- In K8s
    - kubectl get 명령어 실행 시 보는 모든 정보는 etcd 서버에서 가져옴
        - 모든 변경 정보 또한 Etcd 서버에 업데이트 된다
    - etcd가 고가용성 환경에 있는 경우
        - 클러스터 내에 여러 개의 마스터 노드가 있는 경우
        - —initial-cluster에 인스턴스를 기재해야함

### API Server

K8s의 중앙 제어 지점(k8s의 요청을 처리하는 중앙 게이트웨이 느낌)

- k8s 클러스터의 api 엔드포인트
- 모든 kubectl 명령, 컨트롤러, kubelet, 스케줄러 등의 요청을 받아 처리
- etcd에 클러스터 상태를 저장하거나 조회하는 역할
- 기능
    - REST API 제공 : kubectl, 사용자, 다른 컴포넌트는 모두 rest api를 통해 작업 요청
    - 요청 검증, 인증, 인가 처리
    - etcd와 통신 : 객체를 etcd에서 읽고 쓰는 유일한 컴포넌트
    - watch/update 기능 제공 : 클러스터의 상태 변화를 watch할 수 있도록 스트리밍 방식으로 데이터 제공
    - 컨트롤러, Kubelet 등은 이를 통해 필요한 리소스를 감시하고 동기화

### Controller Manager

k8s 내 다양한 컨트롤러 관리하여 클러스터 상태를 원하는 상태로 자동 유지

- 연속적으로 시스템 내 다양한 구성요소들의 상태 모니터링
- 전체적인 시스템이 원하는 기능을 수행할 수 있는 상태로 유지되도록 함
- 실행하는 주요 컨트롤러
    - node-controller : 노드가 살아있는지 감시
    - replication controller : 지정된 수의 Pod 복제본 유지
- 동작 순서
    - controller manager → apiserver로 상태 조회 → 현재 상태화 desired 상태 비교 → 조정(Pod 생성, 삭제 등)

### Scheduler

새로 생성된 Pod을 어떤 노드에 할당할지 결정하는 컴포넌트(실제 할당은 kubelet의 역할)

- 할당 가능한 노드들을 filter하고 우선 순위에 따라 할당 여부 결정

### Kubelet

각 워커 노드에서 실행되는 에이전트, 해당 노드에서 Pod이 올바르게 생성되고 동작하는지를 관리

- 역할
    - pod 실행 관리 : apiserver로부터 podspec 받아 컨테이너 런타임에 전달 및 실행
    - 상태 보고 : 주기적으로 apiserver에 보고
    - 헬스 체크
    - 로컬 리소스 관리(cAdvisor를 내장)
    - 컨테이너 로그, 이벤트 수집

### Proxy

서비스(Service) 리소스에 대한 트래픽을 라우팅 노드마다 하나씩 실행되며, 클러스터 내 네트워크 통신의 중개자 역할

- 클러스터 IP를 가진 서비스에 대한 요청을 실제 파드로 라우팅
- 서비스 디스커버리와 로드 밸런싱 제공
- iptables 또는 IPVS 등을 사용해 성능 좋은 트래픽 분산 처리

### Pod

가장 기본적인 배포 단위이자 실행 단위 

- 하나 이상의 컨테이너가 함께 묶여서 실행되는 최소 단위
- 긴밀히 연결된 컨테이너들을 하나의 유닛으로 묶을 필요가 있음

구성

- 하나 이상의 컨테이너 그룹 (보통은 하나의 컨테이너가 가장 일반적)
- 같은 Pod 안의 컨테이너는:
    - 같은 네트워크 네임스페이스 공유 (localhost 기준으로 통신 가능)
    - 같은 스토리지 볼륨 공유 가능
    - 같은 생명주기(Lifecycle)를 가짐

[Tests]

1. how many `pods` exist on the System
    
    ```bash
    kubectl get po
    ```
    
2. create a new pod with the nginx image
    1. image name: nginx
    
    ```bash
    kubectl run nginx --image=nginx
    ```
    
3. What is the image used to create the new pods?
    
    ```bash
    kubectl describe pod newpods-<id>
    ```
    
4. Which nodes are these pods placed on?
    
    ```bash
    kubectl get pods -o wide
    ```
    
5. How many containers are part of the pod `webapp`?
6. What images are used in the new `webapp` pod?
7. Why do you think the container `agentx` in pod `webapp` is in error?
8. What is the state of the container `agentx` in the pod `webapp`?
    
    ```bash
    kubectl describe pod webapp
    ```
    
9. 
10. What does the `READY` column in the output of the `kubectl get pods` command indicate?
    
    ```bash
    kubectl get po
    ```
    
11. Delete the `webapp` Pod.
    
    ```bash
    kubectl delete pod webapp
    ```
    
12. Create a new pod with the name `redis` and the image `redis123`.
    
    ```bash
    kubectl run redis --image=redis123 --dry-run=client -o yaml > redis-definition.yaml
    kubectl create -f redis-definition.yaml
    kubectl get po
    ```
    
13. 

### ReplicaSet

**Pod의 개수를 일정하게 유지**

- replicas: 3: 항상 3개의 Pod 유지
- selector: 어떤 Pod가 이 ReplicaSet에 의해 관리될지 결정
- template: Pod의 정의 (이걸 기준으로 복제)

`apps/v1`

[Tests]

```bash
kubectl get rs
kubectl describe rs new-replica-set
kubectl api-resources | grep replicaset (API Version 확인용)
kubectl create -f /root/replicaset-definition-1.yaml
```

### Deployment

애플리케이션을 안정적으로 배포, 업데이트, 롤백

내부적으로는 ReplicaSet을 생성하고 관리하면서, Pod의 수를 조절하고 버전을 바꿔주는 역할

[Tests]

### Service

실행 중인 Pod 집합을 묶어 하나의 엔드포인트로 노출

- Pod는 죽었다가 다시 생기면 IP가 바뀜 → Service가 그 변경을 감추고 안정적인 통신 보장
- 로드 밸런싱 기능도 내장
- selector: 이 label을 가진 Pod들을 이 Service가 대상으로 삼음
- port: 클라이언트가 접근할 때 사용하는 포트 (서비스 포트)
- targetPort: 실제 파드에서 열려 있는 포트
- type: 클러스터 안에서만 접근 가능한 내부용 서비스 (기본값)
- NodePort
    - 노드의 포트로부터 들어오는 요청을 pod에 전달하는 역할
    - 사용자가 쿠버네티스 노드 내의 pod에 접속하고자 할 때 사용
        - TargetPort
            - Pod에 붙어있는 포트
        - Port
            - Service에 붙어있는 포트
            - 클러스터 IP와 함께 존재
        - NodePort
            - Node에 붙어있는 포트
            - 30000-32767 (범위)
    - 여러 개의 pod와 연결될 때, 랜덤 알고리즘으로 로드 밸런싱
    - 1(pod):1(node), N:1, N:N일 경우 모두 가능
- ClusterIP
    - 클러스터 내에 가상의 IP를 생성
    - 클러스터 내부에서만 접근 가능
    - 다른 서비스들 간의 통신을 담당 (e.g. 프론트엔드와 백엔드)
    - 여러 개의 서비스 pod(e.g. 백엔드)를 위한 단일한 인터페이스를 제공
- Loadbalancer
    - 로드 트래픽을 여러 다른 웹서버로 분산하는 역할
    - 여러 개의 클러스터 노드 IP에 대해 개별 접속하는 것이 아니라 단일한 경로로 서비스를 사용할 수 있도록 도움
    - NodePort 대신 LoadBalancer 사용할 수 있음
        - Google Cloud Platform 등에서는 사용 가능
        - VirtualBox에서는 사용 불가
- ExternalName : 내부 DNS 이름을 외부 도메인에 매핑

[Tests]

### Namespace

- 자동 생성 네임스페이스
    - Default
        - 클러스터가 셋업될 당시 자동으로 만들어짐
    - kube-system
        - 네트워킹, DNS 등 사용자가 실수로 삭제해서는 안 될 것들을 모아놓음
    - kube-public
        - 모든 사용자들이 이용 가능한 자원
- 서비스와 자원들을 고립시킬 때 유용 (isolation)
    - e.g. 개발환경과 운영환경을 분리할 때
- 네임스페이스마다 다른 정책 사용 가능 (policies)
- 사용 가능한 자원의 한계를 지정 가능 (resource limit)

[Tests]

### Imperative vs Declarative

- imperative
    - 무엇이 필요한지, 어떻게 해야 하는지 단계적 설명 제공
    - 직접적으로 객체의 생성, 변경, 삭제 등을 진행
        - YAML 파일을 변경하지 않고 명령어로 생성, 수정 시에 쿠버네티스 메모리에는 기록이 남으나 로컬 파일에는 변경되지 않으므로 주의 필요
    - `kubectl run --image=nginx nginx`
    - `kubectl create deployment --image=nginx nginx`
    - `kubectl expose deployment nginx --port=80`
    - `kubectl edit deployment nginx`
    - `kubectl scale deployment nginx --replicas=5`
    - `kubectl set image deployment nginx nginx=nginx:1.18`
    - `kubectl create -f nginx.yaml`
    - `kubectl replace -f nginx.yaml`
    - `kubectl delete -f nginx.yaml`
- Declarative
    - 필요한 것들만 명시, 시스템이 알아서 진행
    - configuration을 시스템이 확인하고 알아서 생성, 변경, 삭제 등을 진행
    - `kubectl apply -f nginx.yaml`
        - 쿠버네티스의 live object configuration에 정보 저장됨 (다른 명령어와 동일)
        - json 포맷으로 변경되어 마지막으로 적용된 configuration 저장 (다른 명령어와 다름)
            - live object configuration 내에 저장됨
            - 어떤 필드가 삭제되었는지 확인 용이

[Tests]