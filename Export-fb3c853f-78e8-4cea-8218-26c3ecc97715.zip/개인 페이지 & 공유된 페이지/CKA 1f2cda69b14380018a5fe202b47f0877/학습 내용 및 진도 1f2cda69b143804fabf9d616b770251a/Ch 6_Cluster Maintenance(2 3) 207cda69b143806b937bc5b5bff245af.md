# Ch 6_Cluster Maintenance(2/3)

사람: Dahui Kim
완료 여부: Yes
작성일: 2025년 6월 16일
주차: 3주차

1. This lab tests your skills on **upgrading a kubernetes cluster**. We have a production cluster with applications running on it. Let us explore the setup first. What is the current version of the cluster?
    
    ```bash
    k get nodes //클러스터의 각 노드가 사용하는 Kubelet 버전
    
    k version //kubectl 명령 자체와 서버(API 서버)의 버전
    ```
    
2. How many nodes are part of this cluster?
Including controlplane and worker nodes
    
    ```bash
    k get nodes
    ```
    
3. How many nodes can host workloads in this cluster?
Inspect the applications and taints set on the nodes.
    1. taints: 
    • 특정 조건을 설정해서 schedule 방지
    
    ```bash
    **k describe nodes {노드이름} | grep -i taints**
    ```
    
4. How many applications are hosted on the cluster?Count the number of deployments in the `default` namespace.
    1. deployment: **애플리케이션의 대표 단위**
        - 하나의 **애플리케이션(서비스/마이크로서비스 등)** 을 **관리**하기 위한 리소스
        - 주로 1개의 앱/서비스를 대표하며:
            - 몇 개의 파드를 유지할지
            - 어떤 컨테이너 이미지로 동작할지
            - 어떻게 롤링 업데이트를 할지 등을 정
        
        | **리소스 종류** | **설명** |
        | --- | --- |
        | **Deployment** | 일반적으로 하나의 앱을 의미하기 때문에 가장 직관적 |
        | Pod | 여러 개로 복제되므로 수가 많고 앱 단위를 알기 어려움 |
        | ReplicaSet | Deployment에 의해 자동 생성되므로 직접 보는 건 드뎌 의미 없음 |
        | Service | 여러 deployment가 하나의 서비스 뒤에 붙을 수도 있어 정확도 떨어짐 |
    
    ```bash
    k get deploy
    ```
    
5. What nodes are the pods hosted on?
    
    ```bash
    k get po -o wide
    ```
    
6. You are tasked to upgrade the cluster. Users accessing the applications must not be impacted, and you cannot provision new VMs. What strategy would you use to upgrade the cluster?
    1. 사용자 영향 x
    2. scale-out이나 새로운 노드 추가 불가(vm 생성 불가)
    
    ```bash
    노드를 하나씩 순서대로 비워가며 업그레이드하는 rolling upgrade strategy
    ```
    
7. What is the latest version available for an upgrade with the current version of the kubeadm tool installed? Use the `kubeadm` tool
    
    ```bash
    kubeadm upgrade plan
    ```
    
8. We will be upgrading the controlplane node first. Drain the controlplane node of workloads and mark it `UnSchedulable`
    
    ```bash
     drain controlplane --ignore-daemonsets
    ```
    
9. Upgrade the `controlplane` components to exact version `v1.32.0`
    
    Upgrade the kubeadm tool (if not already), then the controlplane components, and finally the kubelet. Practice referring to the Kubernetes documentation page
    
    - apt 저장소 위치: /etc/apt/sources.list.d/kubernetes.list
    - [https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-upgrade/](https://kubernetes.io/docs/tasks/administer-cluster/kubeadm/kubeadm-upgrade/)
    
    ```bash
    vim /etc/apt/sources.list.d/kubernetes.list
    apt-cache mdison kubeadm //업그레이드 가능한 kubeadm 버전 확인
    apt-get install kubeadm=1.32.0-1.1
    kubeadm upgrade plan v1.32.0
    kubeadm upgrade apply v1.32.0
    //drain 
    apt-get install kubelet=1.32.0-1.1
    //reload(kubelet 재시작)
    systemctl daemon-reload //systemd가 서비스 설정 변경을 다시 읽도록 함
    systemctl restart kubelet
    
    kubectl uncordon controlplane
    ```
    
10. Next is the worker node. `Drain` the worker node of the workloads and mark it `UnSchedulable`
11.